import {isWX} from '../../utils/util.js'
import {util} from '../../utils/util2.js'
let flag =GB.utils.GetRequest()['flag']||'';
let token=GB.utils.GetRequest()['token']||'';
let iosan=GB.utils.getPlatform();
   // if(!flag&& !isWX()){
   // 	  //
   // 	  location.href= 'download.html';
   // }
const vue = new Vue({
	el:".download-total",
	data:{
       list:{},//返回的版本数据
       anzhuo:false,
       ios:false,
       version:'',
       link:'',
       open:false,
       tann:false
	},
	created(){
		this.Edition();


        if (iosan=="android") {
          	this.anzhuo=true;
        }else{
        	this.ios=true
        }
	},
	mounted(){
		
	},
	methods:{
        // 版本信息
        Edition(){
        	this.$http.get(proxypath+"/v1/app_version/getAppVersion"
        		).then((res)=>{
              if (res.body.code===200) {
                    this.open=true;
                    console.log(res)
                    this.list=res.body.data;
                    if(iosan=="android"){
                              this.version=this.list.androidVersion;
                              //this.link="https://download.bitget.com/android/bitget_v"+this.version+".apk";
                              this.link="https://download.bitget.com/android/bitget-release.apk";
                              
                    } else{
                      this.version=this.list.iosVersion;
                    }
              }else{

                    if (res.body.msg) {
                         util.toast(res.body.msg)
                    }
              }
        		},(err)=>{ 
        			console.log(err)
        		})
        },
        // 判断Android下载还是ios下载
        down(){

             if (isWX()) {
                if (iosan=="android") {
                  this.dialogg();
                  }else{
                    GB.utils.iosdownLoad();
                  }
             }else{

                  if (iosan=="android") {
                        window.location.href = this.link;
                  }else{
                    GB.utils.iosdownLoad();
                  }
             }


            // if (iosan=="android") {
            //       window.location.href = this.link;
            // }else{
            //   GB.utils.iosdownLoad();
            // }
        },
                // 浏览器弹框
       dialogg(){

               this.tann=true

        },
        yin(){
          this.tann=false
        }
	},
	filters:{
	}
})