import {isWX} from '../../utils/util.js'
import {util} from '../../utils/util2.js'
let flag =GB.utils.GetRequest()['flag']||'';
let token=GB.utils.GetRequest()['token']||'';
let iosan=GB.utils.getPlatform();

   if(!flag&& !isWX()){
   	  //
   	  location.href= basePath+'/html/pages/redactivity/download.html';
   }
const vue = new Vue({
	el:".ios-course",
	data:{
       list:{},
       anzhuo:false,
       iosx:false,
       redall:[],
       token:token,
       iosan:iosan,
       redrate:0,
       tann:false,//弹框
       hui:0
	},
	created(){
      this.rate();
  		this.allred();  
      if (this.iosan=="android") {
            this.anzhuo=true;
      }else{
      	this.iosx=true
      }
	},
	mounted(){
	},
	methods:{
				// 弹框
       dialog(){

             var  html=$("#dialog-template").html();

             GB.utils.showhtml({
                 content:html,
                 eventHandler(){
                    var $boudingBox=this.boudingBox;

                    //函数内部的 this  是 这个 dialog对象 

                    var that=this;
                    $boudingBox.on("click",'.sure-btn',function(){
                         
                         that.destroy();



                    })
                 }
             })

        },

        // 浏览器弹框
       dialogg(){

               this.tann=true

        },
        yin(){
        	this.tann=false
        },
        // 红包奖励
        allred(){
        	var param={activeCode:"receiveGiftAct",token:this.token}
        	this.$http.post(proxypath+"/v1/envelopeActivity/userHaveToReceiveH5",
        		param,
        		{emulateJSON:true}
        		).then((res)=>{
        			if (res.body.code===200) {
                			console.log(res)
		        			var list=res.body.data.rewardList||[];
		        			 list.forEach((item)=>{
		                        if(item.rewardType==1){
		                        	//充值红包
		                        	this.redall=item;
                              this.hui=(Number(this.redrate)*this.redall.rewardCoin).toFixed(2)
		                        }
		        			 })
        			}else{
        				util.toast("获取数据失败")
        			}

        		},(err)=>{ 
        			console.log(err)
        		})
        },
        // 判断Android下载还是ios下载
        down(){
            // if (this.iosan=="android") {
            //      this.dialogg();
            // }else{
            //       GB.utils.iosdownLoad();
            // }
            window.location.href=basePath+'/html/pages/redactivity/download.html?random='+parseInt(Math.random()*10000000)
        },
        // 汇率转换
          rate(){
        	this.$http.post(proxypath+"/v1/envelopeActivity/tradingCurrency",{},
        		{emulateJSON: true}
          	).then((res)=>{
          		console.log(res)
          		if (res.body.code===200) {
                      this.redrate=res.body.data
          		}else{
		               if (res.body.msg) {
                         util.toast(res.body.msg)
                    }
          		}
          		
          	},(err)=>{
          		console.log(err)
          	})
        }
	},
	filters:{
	}
})