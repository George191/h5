import {util} from '../../utils/util2.js'
const vue = new Vue({
    el:".pucket-activity",
    data:{
        urls: "",
        tokens: "",
        conversion: "",
        packetnum: 0,
        errmsg: "1",
        nologgiftId: "",
        czrewardCoin: "",
        rewardCoin: "",
        czcoinCode: "",
        coinCode: "",
        recelist: [],
        wlogin: 1,
        logstatus: false,
        lingmsg: false,
        logipack: false,
        rechargemsg: false,
        chongzhi: false,
        terminalType: "",
        arr: []
    },
    created(){
        // alert("111");
        let _this = this;
        let params = GB.utils.GetRequest()['params'];
        let token = GB.utils.GetRequest()['token'];
        this.urls = params;
        this.tokens = token;
        console.log(this.tokens);
        if(params){
            params=JSON.parse(params);
        }
        this.logstatus = token ? true : false;
        console.log(this.logstatus);

        if(GB.utils.getPlatform() === "android"){
            this.terminalType = 2
        }else{
            this.terminalType = 3
        }

        if(this.logstatus){
             var obj = {};
            if(params){
                obj = {
                    activeCode: "receiveGiftAct",
                    token: _this.tokens,
                    giftId: params.giftId,
                    appVersion:"1",
                    charset:"UTF8",
                    language:"zh",
                    terminalCode:"WEB",
                    terminalType: _this.terminalType,
                    terminalVersion:"1",
                    version:"1.0"
                }
            }else{
                obj = {
                    activeCode: "receiveGiftAct",
                    token: _this.tokens,
                    appVersion:"1",
                    charset:"UTF8",
                    language:"zh",
                    terminalCode:"WEB",
                    terminalType: _this.terminalType,
                    terminalVersion:"1",
                    version:"1.0"
                }
            }

            // 查询绑定红包
            this.$http.post(appproxypath + "/app/v2/envelopeActivity/userHaveToReceiveApp",obj,
                {emulateJSON: true}
            ).then(function(response){
                let res = JSON.parse(response.body);
                console.log(res);
                if(res.code === "00000"){
                    if(res.data.userRewardResult.rewardList.length>0){
                        let datas = res.data.userRewardResult.rewardList
                        datas.forEach(item=>{
                           // rewardType 1:注册红包 2：充值红包
                           if(item.rewardType === 1){
                               _this.packetnum+=1;
                               //改变红包图片为拆包
                               _this.wlogin = 2;
                               // 赋值单位
                               _this.rewardCoin = item.rewardCoin;
                               //giftId
                               // _this.nologgiftId = res.data.receiveGiftResult.giftId;
                               // 赋值红包大小
                               _this.coinCode = item.coinCode;
                           }
                            if(item.rewardType === 2){
                                _this.packetnum+=1;
                                _this.chongzhi = true;
                                // 赋值单位
                                _this.czrewardCoin = item.rewardCoin;
                                // 赋值红包大小
                                _this.czcoinCode = item.coinCode;
                            }

                        });

                    }

                }else{
                   if(res.msg){
                       GB.utils.toast(res.msg);
                   }
                }


            },function(err){
                console.log(err)
            });
        }

        // 红包记录  proxypath
        $.post(appproxypath+"/app/v2/envelopeActivity/getAfterLoginReceiveRedEnvelopeAll",
        {
            activeCode: "receiveGiftAct",
            appVersion:"1",
            charset:"UTF8",
            language:"zh",
            terminalCode:"WEB",
            terminalType: _this.terminalType,
            terminalVersion:"7.0",
            version:"1.0"
        },function (res) {
            let datas = JSON.parse(res);
            if (datas.code === "00000") {
                _this.recelist = datas.data.rewardItem
            }
        })

        $.post(appproxypath+"/app/v2/envelopeActivity/tradingCurrency",
            function (res) {
                let datas = JSON.parse(res);
                if (datas.code === 200) {
                    console.log(datas);
                    _this.conversion = datas.data;
                    console.log(_this.conversion)
                }
            })


    },
    filters:{
        converfun(val){
            let number = val*this.conversion;
            let retval = number.toFixed(2);
            return retval
        }
    },
    mounted(){

    },
    methods:{
        gozich(){
            GB.utils.goCapital({});
        },
        // 跳转登录
        recebtn(){
            var param={giftId:this.nologgiftId};
            GB.utils.goLogin(param);
        },
        // 跳转推荐返佣
        gorecommend(){
            GB.utils.getReward({});
        },
        // 注册红包领取
        chaipuckbtn(){
            let _this = this;

            if(!this.logstatus){
                // 点击红包接口
                this.$http.post(appproxypath+"/app/v2/envelopeActivity/notLoggedEnvelope",{
                        activeCode: "receiveGiftAct",
                        appVersion:"1",
                        charset:"UTF8",
                        language:"zh",
                        terminalCode:"WEB",
                        terminalType: _this.terminalType,
                        terminalVersion:"1",
                        version:"1.0"},
                    {emulateJSON: true}
                ).then(function(response){
                    // console.log(response.body);
                    let res = JSON.parse(response.body);
                    console.log(res);
                    if(res.code === "00000"){
                        _this.packetnum+=1;
                        _this.lingmsg = true;
                        //改变红包图片为拆包
                        _this.wlogin = 2;
                        // 赋值单位
                        _this.rewardCoin = res.data.receiveGiftResult.rewardCoin;
                        //giftId
                        _this.nologgiftId = res.data.receiveGiftResult.giftId;
                        // 赋值红包大小
                        _this.coinCode = res.data.receiveGiftResult.coinCode;
                    }else if(res.code === "ACT000002"){
                        // 红包被领完了
                        _this.errmsg = 3;
                        _this.rechargemsg = true;
                    }else{
                        // if(res.code === "ACT000003")
                        // 当前人数过多
                        _this.errmsg = 4;
                        _this.rechargemsg = true;
                    }
                    // else{
                    //     // 错误弹框
                    //     _this.errmsg = 4;
                    //     _this.rechargemsg = true;
                    // }

                },function(err){
                    console.log(err)
                });
            }else{
                // 登录后领取注册红包
                this.$http.post(appproxypath+"/app/v2/envelopeActivity/getAfterLoginReceiveRedEnvelopeApp",{
                        activeCode: "receiveGiftAct",
                        appVersion:"1",
                        token: _this.tokens,
                        activeType: "1",
                        charset:"UTF8",
                        language:"zh",
                        terminalCode:"WEB",
                        terminalType: _this.terminalType,
                        terminalVersion:"1",
                        version:"1.0"},
                    {emulateJSON: true}
                ).then(function(response){
                    let res = JSON.parse(response.body);
                    console.log(res);
                    if(res.code === "00000"){
                        _this.packetnum+=1;
                        _this.lingmsg = true;
                        //改变红包图片为拆包
                        _this.wlogin = 2;
                        // 赋值单位
                        _this.rewardCoin = res.data.receiveGiftResult.rewardCoin;
                        //giftId
                        // _this.nologgiftId = res.data.receiveGiftResult.giftId;
                        // 赋值红包大小
                        _this.coinCode = res.data.receiveGiftResult.coinCode;
                    }else if(res.code === "ACT000002"){
                        // 红包被领完了
                        _this.errmsg = 3;
                        _this.rechargemsg = true;
                    }else{
                        // if(res.code === "ACT000003")
                        // 当前人数过多
                        if(res.code === "ACT000003"){
                            _this.errmsg = 4;
                            _this.rechargemsg = true;
                        } else{
                            if(res.msg){
                                util.toast(res.msg);
                            }
                        }
                      
                    }
                },function(err){
                    console.log(err)
                });
            }


        },
        offling(){
            this.lingmsg = false
        },
        // 已登陆领取
        yiloginpuck(){
            this.logipack = true;
            if(this.logstatus === false){

            }
        },
        offloginling(){
            this.logipack = false
        },
        // 充值拆包
        chargemoney(){
            let _this = this

            if(this.logstatus === false || (this.logstatus&&this.wlogin === 1)){
                // 未登录
                this.rechargemsg = true;
                this.errmsg = 1;

            }else{

                // 登录后领取红包
                this.$http.post(appproxypath+"/app/v2/envelopeActivity/getAfterLoginReceiveRedEnvelopeApp",{
                        activeCode: "receiveGiftAct",
                        appVersion:"1",
                        token: _this.tokens,
                        activeType: "2",
                        charset:"UTF8",
                        language:"zh",
                        terminalCode:"WEB",
                        terminalType: _this.terminalType,
                        terminalVersion:"1",
                        version:"1.0"},
                    {emulateJSON: true}
                ).then(function(response){
                    let res = JSON.parse(response.body);
                    console.log(res);
                    if(res.code === "00000"){
                        _this.packetnum+=1;
                        _this.logipack = true;
                        //改变充值红包图片为拆包
                        _this.chongzhi = true;
                        // 赋值单位
                        _this.czrewardCoin = res.data.receiveGiftResult.rewardCoin;
                        //giftId
                        // _this.nologgiftId = res.data.receiveGiftResult.giftId;
                        // 赋值红包大小
                        _this.czcoinCode = res.data.receiveGiftResult.coinCode;
                    }else if(res.code === "ACT000002"){
                        // 红包被领完了
                        _this.errmsg = 3;
                        _this.rechargemsg = true;
                    }else if(res.code === "ACT000004" || res.code === "222222"){
                        // 累计充币满1个ETH可拆
                        _this.errmsg = 2;
                        _this.rechargemsg = true;
                    }else{
                        // 当前人数过多
                        if(res.code === "ACT000003"){
                            _this.errmsg = 4;
                            _this.rechargemsg = true;
                        } else{
                            if(res.msg){
                                util.toast(res.msg);
                            }
                        }
                    }
                },function(err){
                    console.log(err)
                });

            }
        },
        rechargebtn(){
            this.rechargemsg = false
        },

    },
    filters:{

    }
})