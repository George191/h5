import {util} from '../../utils/util2.js'

import util1 from '../../utils/util1.js'

//无痕验证初始化代码
//util1.NVC_Opt_register();

window.NVC_Opt = {
  //无痕配置 && 滑动验证、刮刮卡通用配置
  appkey: "FFFF0N0N000000006825",
  //appkey:'CF_APP_1',
  scene: "nvc_register_h5",
  isH5: true,
  popUp: false,
  renderTo: '#captcha',
  //trans: { "key1": "code0", "nvcCode": 400 }, //测试代码
  language: "cn",
  //滑动验证长度配置
  customWidth: 300,
  nvcCallback: function (data) {
    // data为getNVCVal()的值，此函数为二次验证滑动或者刮刮卡通过后的回调函数
    // data跟业务请求一起上传，由后端请求AnalyzeNvc接口，接口会返回100或者900
    let param = {
      regName: vm.loginName,
      password: vm.password,
      regType: vm.sendType,
      NVC:data,
      recommendCode: vm.invitationCode,//推荐码
      registerCode: vm.registerLimitCode//注册码
    };
    if (vm.sendType === 1) {
      param.ecode = vm.msgCode1;
    } else {
      param.pcode = vm.msgCode;
    }
    Vue.http.post(
      proxypath + "/v1/regist/register",
      // "http://192.168.1.15:8080/v1/regist/register",
      vm.objToUrl(param),
      {
        headers: {"Content-Type": "application/x-www-form-urlencoded"}
      }
    )
      .then(function (res) {
        if (res.body.code == 100 || res.body.code == 200) {
          //注册成功
          vm.zctrorfal = false;
        } else if (res.body.code == 800 || res.body.code == 900) {
          //直接拦截
          vm.isRegister = false;
          util.toast('请刷新页面后，重新注册');
        } else {
          vm.isRegister = false;
          if (res.body.msg) {
            util.toast(res.body.msg)
          }
        }
      }, function (err) {
        console.log(err)
      })
  }
}


const vm = new Vue({
  el: ".register",
  data: {
    sendType: 0,
    loginName: "",//手机号
    password: "",//一次密码
    compassword: "",//二次密码
    msgCode: "",//短信验证码
    msgCode1: "",//邮箱验证码
    xuan: true,//控制勾选
    msgText: "获取验证码",
    msgText1: "获取验证码",
    invitationCode: "",//推荐码
    registerLimitCode: "",//注册码
    isRegister: false,//控制注册
    zctrorfal: true,//控制注册成功后的显示
    isSendMsg: false,
    isSendMsg1: false,
    code: "",
    alerttr: false,//控制安全锁
    showNewCaptcha: false,
    isPassCapcha: false,
    settims: 0,
    needRegisterLimitCode: 0,
    id: "",
    cloudShow:false  //控制滑块是否显示
  },
  created() {
    //加载无痕代码
    util1.loadJs('//g.alicdn.com/sd/nvc/1.1.112/guide.js?random=' + Math.random())
  },
  mounted() {

  },
  methods: {
    objToUrl(obj) {
      if (!obj) {
        return '';
      }
      let params = [];
      for (const key in obj) {
        if (obj.hasOwnProperty(key)) {
          const element = obj[key];
          params.push(encodeURIComponent(key) + '=' + encodeURIComponent((element === undefined ? '' : element)));
        }
      }
      return params.join("&");
    },
    initNECaptchaa() {
      initNECaptcha({
        // config对象，参数配置
        captchaId: 'c722e7341bbd44cbacf6af4842cdb5a4',
        element: '#captcha',
        mode: 'float',
        width: '320px',
        onVerify: (err, ret) => {
          // 用户验证码验证成功后，进行实际的提交行为
          // todo
          console.log(ret)
          this.code = ret['validate']
          this.isPassCapcha = true
          this.sendMsg();
        }
      }, function (instance) {
        console.log(instance)
        // 初始化成功后得到验证实例instance，可以调用实例的方法
      }, function (err) {
        // 初始化失败后触发该函数，err对象描述当前错误信息
        console.log(err)
      })
    },
    gouxuan() {
      this.xuan = !this.xuan
    },
    // 手机
    photo() {
      if (this.loginName === "") {
        return
      }
      if (this.sendType === 0 && !(util.telReg.test(this.loginName))) {
        util.toast("您输入的账号(邮箱或手机号码)格式有误")
      } else if (this.sendType === 0 && (util.telReg.test(this.loginName))) {
        // this.valid.loginName = "";
      }
      if (this.sendType === 1 && !(util.emailReg.test(this.loginName))) {
        util.toast("您输入的账号(邮箱或手机号码)格式有误")
      } else if (this.sendType === 1 && (util.emailReg.test(this.loginName))) {
        // this.valid.loginName = "";
      }
    },
    // 密码
    pasworinp() {
      if (this.password.length === 0) {
        return
      }
      if (!(util.pwdReg.test(this.password))) {
        util.toast("密码需包含字母、数字或特殊字符且长度在6~32位")
        // return false;
      }
      if (this.password.length < 6) {
        util.toast("密码需包含字母、数字或特殊字符且长度在6~32位")
        // return false
      }
    },
    pasworqr() {
      if (this.compassword.length > 0 && this.password.length > 0 && this.password !== this.compassword) {
        util.toast("两次密码不一致")
        return false
      }
    },
    // 验证码
    sendMsg() {

      if (this.sendType === 0) {
        if (this.isSendMsg) {
          return false;
        }
        if (!this.validLoginName()) {
          return false;
        }
        if (!this.validpwd()) {
          return false
        }
        if (!this.validcpwd()) {
          return false
        }
        if (!this.validTwoPwd()) {
          return false;
        }
        // if(!this.isPassCapcha){
        // 	this.showNewCaptcha = true;
        // 	return false;
        // }
        let param = {
          type: 11,
          msgtype: 1,
          phone: this.loginName,
          // NECaptchaValidate: this.code,
          userId: "",
          areaCode: "86"
        }
        this.$http.post(proxypath + "/v1/send/regist_send_phone",
          this.objToUrl(param),
          {headers: {"Content-Type": "application/x-www-form-urlencoded"}})
          .then(function (res) {
            console.log(res)
            if (res.body.code === 200) {
              this.isSendMsg = true;
              this.settims = util.tickerCountDown(60, 1000, (sec) => {
                if (sec > 0) {
                  this.msgText = sec + "s";
                } else {
                  // 	this.isPassCapcha = false;
                  // this.showNewCaptcha = false;
                  //	this.initNECaptchaa();
                  this.msgText = "重新获取";
                  this.isSendMsg = false;
                }
              })
            } else {
              this.isSendMsg = false;
              //         		    this.isPassCapcha = false;
              // this.showNewCaptcha = false;
              //this.initNECaptchaa();
              if (res.body.code === 10020) {

                util.toast("该手机号已被使用")
              } else {
                util.toast(res.body.msg);
              }
            }
          }, function (err) {
            console.log(err)
          })
      } else {
        if (this.isSendMsg1) {
          return false;
        }
        if (!this.validLoginName()) {
          return false;
        }
        if (!this.validpwd()) {
          return false
        }
        if (!this.validcpwd()) {
          return false
        }
        if (!this.validTwoPwd()) {
          return false;
        }

        // if(!this.isPassCapcha){
        // 	this.showNewCaptcha = true;
        // 	return false;
        // }
        let param = {
          type: 3,
          msgtype: 1,
          address: this.loginName,
          // NECaptchaValidate: this.code,
          userId: ""
        }
        this.$http.post(proxypath + "/v1/send/regist_send_email",
          this.objToUrl(param),
          {headers: {"Content-Type": "application/x-www-form-urlencoded"}})
          .then(function (res) {
            console.log(res)
            if (res.body.code === 200) {
              this.isSendMsg1 = true;
              this.settims = util.tickerCountDown(60, 1000, (sec) => {
                if (sec > 0) {
                  this.msgText1 = sec + "s";
                } else {
                  this.isSendMsg1 = false;
                  // this.isPassCapcha = false;
                  // this.showNewCaptcha = false;
                  //this.initNECaptchaa();
                  this.msgText1 = "重新获取";
                }
              })
            } else {
              this.isSendMsg1 = false;
              //  		        this.isPassCapcha = false;
              // this.showNewCaptcha = false;
              //this.initNECaptchaa();
              if (res.body.code === 10020) {
                util.toast("该邮箱已被使用")
              } else {
                util.toast(res.body.msg);
              }
            }
          }, function (err) {
            console.log(err)
          })
      }


    },

    // 手机号
    validLoginName() {
      if (this.sendType === 1) {
        //邮箱
        if (this.loginName === "") {
          util.toast("请输入邮箱账号")
          return
        }
        if (!(util.emailReg.test(this.loginName))) {
          util.toast("您输入的邮箱格式有误")
          return false;
        }
      } else {
        //手机
        if (this.loginName === "") {
          util.toast("请输入手机号")
          return
        }
        if (!(util.telReg.test(this.loginName))) {
          util.toast("您输入的手机号码格式有误")
          return false;
        }
      }
      return true;
    },
    validpwd() {
      if (this.password.length === 0) {
        util.toast("请设置密码")
        return false;
      }
      if (!(util.pwdReg.test(this.password))) {
        util.toast("密码需包含字母、数字或特殊字符且长度在6~32位")
        return false;
      }
      if (this.password.length < 6) {
        util.toast("密码需包含字母、数字或特殊字符且长度在6~32位")
        return false;
      }
      return true
    },
    validcpwd() {
      if (this.compassword.length === 0) {
        util.toast("请再次输入密码")
        return false
      }
      return true
    },
    // 密码
    validTwoPwd() {
      if (this.compassword.length > 0 && this.password.length > 0 && this.password !== this.compassword) {
        util.toast("两次密码不一致")
        return false;
      }
      return true;
    },
    // 验证码
    validMsgCode() {
      if (this.sendType === 0) {
        if (this.msgCode.length === 0) {
          util.toast("请输入短信验证码")
          return false;
        }
        if (this.msgCode.length < 6) {
          util.toast("短信验证码格式错误,请重新输入")
          return false;
        }
      } else {
        if (this.msgCode1.length === 0) {
          util.toast("请输入邮箱验证码")
          return false;
        }
        if (this.msgCode1.length < 6) {
          util.toast("邮箱验证码格式错误,请重新输入")
          return false;
        }
      }
      return true;
    },
    // 注册
    register() {
      if (this.isRegister) {
        return false;
      }
      // 手机号
      if (!this.validLoginName()) {
        return false;
      }

      // 密码
      if (!this.validpwd()) {
        return false
      }
      if (!this.validcpwd()) {
        return false
      }
      if (!this.validTwoPwd()) {
        return false;
      }

      // 验证码
      if (!this.validMsgCode()) {
        return false;
      }

      // 如果是注册码模式需要验证注册码不为空
      if (this.needRegisterLimitCode === 1 && this.registerLimitCode === '') {
        util.toast("请输入注册码")
        return false;
      }

      if (!this.xuan) {
        util.toast("请先同意并勾选用户协议")
        return false;
      }

      this.isRegister = true;

      let param = {
        regName: this.loginName,
        password: this.password,
        regType: this.sendType,
        recommendCode: this.invitationCode,//邀请码
        registerCode: this.registerLimitCode//注册码
      };
      if (this.sendType === 1) {
        param.ecode = this.msgCode1;
      } else {
        param.pcode = this.msgCode;
      }

      // 添加人机验证的代码

      let nvcMsg = getNVCVal();

      param.NVC = nvcMsg;


      var that = this;
      // 注册
      this.$http.post(
        proxypath + "/v1/regist/register",
        // "http://192.168.1.15:8080/v1/regist/register",
        this.objToUrl(param),
        {
          headers: {"Content-Type": "application/x-www-form-urlencoded"}
        }
      )
        .then(function (res) {
          // if (res.body.code === 200) {
          // 	this.zctrorfal = false;
          // } else {
          // 	this.isRegister = false;
          // 	util.toast(res.body.msg)
          // }
          if (res.body.code == 400 || res.body.code == 600) {
            this.cloudShow=true;
            //唤醒滑动验证
            getNC().then(function () {
              NoCaptcha.upLang('cn', {
                'LOADING': "加载中...",//加载
                'SLIDER_LABEL': "请按住滑块，滑动到最右边",//等待滑动
                'CHECK_Y': "验证通过",//通过
                'ERROR_TITLE': "哎呀，出错了，点击<a href=\"javascript:NoCaptcha.reset()\">刷新</a>再来一次",//拦截
                'CHECK_N': "验证未通过", //准备唤醒二次验证
                'OVERLAY_INFORM': "经检测你当前操作环境存在风险，请输入验证码",//二次验证
                'TIPS_TITLE': "验证码错误，请重新输入",//验证码输错时的提示
                '_errorNetwork': "网络不给力，请<a href=\"javascript:NoCaptcha.reset()\">点击刷新</a>",
              });
              _nvc_nc.reset();
            })
            //util1.NVC_Opt_sec();
          } else if (res.body.code == 100 || res.body.code == 200) {
            //注册成功
            that.zctrorfal = false;
          } else if (res.body.code == 800 || res.body.code == 900) {
            //直接拦截
            that.isRegister = false;
            util.toast('请刷新页面后，重新注册');
          } else {
            that.isRegister = false;
            if (res.body.msg) {
              util.toast(res.body.msg)
            }
          }
        }, function (err) {
          console.log(err)
        })
    }
  },
  filters: {},
  watch: {
    loginName(val) {
      if (this.sendType === 0) {
        let zzval = /^[0-9]*$/;
        if (!zzval.test(val)) {
          this.loginName = val.slice(0, val.length - 1)
        }
      }
    },
    password(val) {
      if (val.length > 32) {
        this.valid.password = "密码需包含字母、数字或特殊字符且长度在6~32位"
        return
      }
    },
    "sendType": function (val) {
      if (val === 0) {
        //短信
        this.placeHolder = "请输入短信验证码";
        clearInterval(this.settims);
        this.isSendMsg = false;
        this.msgText = "获取短信验证码";
      } else {
        console.log("1")
        //邮箱
        this.placeHolder = "请输入邮箱验证码";
        clearInterval(this.settims1);
        this.msgText1 = "获取邮箱验证码";
        this.isSendMsg1 = false;
      }
      this.invitationCode = "";
      // this.registerLimitCode = "";
      // this.photdisab = false;
      this.loginName = "";
      this.msgCode = "";
      this.msgCode1 = "";
      this.password = "";
      this.compassword = "";
      this.showNewCaptcha = false;
    }
  },
})