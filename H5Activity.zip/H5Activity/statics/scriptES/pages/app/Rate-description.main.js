import {util} from '../../utils/util2.js'
const vue = new Vue({
	el:".rate",
	data:{
        arr:[]
	},
	created(){
		
		// this.$http.post(proxypath+"/v1/bottom/fee_rate_list").then((res)=>{
		// 	console.log(res)
	 //        if (res.body.code === 200) {
  //                  this.arr = res.body.data
	 //        }
		// },(err)=>{

		// })


		// $.post("/v1/bottom/fee_rate_list", function (data) {
  //           $(".loader-total").hide();
  //           if (data.code === 200) {
  //               var tableList = $(".table_list");
  //               for (var i = 0; i < data.data.length; i++) {
  //                   var tableLi = $("<div class='table_li'></div>");
  //                   var span1 = $("<span></span>").text(data.data[i].fshortname);
  //                   var span2 = $("<span></span>").text(data.data[i].makerFeeRate);
  //                   var span3 = $("<span></span>").text(data.data[i].takerFeeRate);
  //                   tableLi.append(span1).append(span2).append(span3);
  //                   tableList.append(tableLi);
  //               }
  //           } else {
  //               $(".no-data").show();
  //           }
  //       })
	},
	mounted(){
		// this.$http.post(proxypath+"/v1/bottom/fee_rate_list").then((res)=>{
		// 	// console.log(res)
	 //        if (res.body.code === 200) {
  //                  this.arr = res.body.data
	 //        }
		// },(err)=>{
		// 	this.errMsg = JSON.stringify(err);
		// 	util.toast("数据获取失败")
		// })
		let that = this;
		$.post(proxypath + "/v1/bottom/fee_rate_list",function(res){
			console.log(res)
			that.arr =res.code;
	        if (res.code === 200) {
               that.arr = res.data
	        }
		})

	},
	methods:{

	},
	filters:{

	}
})