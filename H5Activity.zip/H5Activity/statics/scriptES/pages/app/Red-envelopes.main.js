import {util} from '../../utils/util2.js'
import {isWX} from '../../utils/util.js'


let token=GB.utils.GetRequest()['token']||'';
let resource=GB.utils.GetRequest()['resource']||'';
let  recommendCode=GB.utils.GetRequest()['recommendCode']||'';

const vue = new Vue({
	el:".red-avtivity",
	data:{
		redswitch:true,//控制红包拆与不拆
		redshu:{},//获取红包的数据  
		redrate:null,//红包转换汇率
		token:token,
		resource:resource,
		hui:0
	},
	mounted(){
	},
	created(){
		this.rate();
		console.log(this.resource);
		console.log(this.token)
	},
	methods:{
		objToUrl(obj) {
		    if (!obj) {
		      return '';
		    }
		    let params = [];
		    for (const key in obj) {
		      if (obj.hasOwnProperty(key)) {
		        const element = obj[key];
		        params.push(encodeURIComponent(key) + '=' + encodeURIComponent((element === undefined ? '' : element)));
		      }
		    }
		    return params.join("&");
		  },
		// 弹框
       dialog(){

             var  html=$("#dialog-template").html();

             GB.utils.showhtml({
                 content:html,
                 eventHandler(){
                    var $boudingBox=this.boudingBox;

                    //函数内部的 this  是 这个 dialog对象 

                    var that=this;
                    $boudingBox.on("click",'.sure-btn',function(){
                         
                         that.destroy();



                    })
                 }
             })

        },
        // 拆红包
        chai(){
        	console.log("红包已拆")
        	var param={activeCode:"receiveGiftAct",activeType:1,token:this.token}   // 加token
        	var url = this.resource==2 ? proxypath+"/v1/envelopeActivity/notLoggedEnvelope" : proxypath+"/v1/envelopeActivity/getAfterLoginReceiveRedEnvelopeH5"
          	this.$http.post(
	          	url,
	          	param,
	          	{emulateJSON: true}
			).then((res)=>{
				console.log(res)
				if (res.body.code==200) {
					if (this.resource==2) {
						  this.redshu=res.body.data
						  console.log(this.redshu)
                          this.hui=Number(this.redrate*this.redshu.rewardCoin).toFixed(2)
						  this.redswitch=false
					}else{
						if (isWX()) {
							window.location.href = proxypathone+"/html/pages/redactivity/ios-course.html?token="+this.token;
						}else{
							window.location.href = proxypathone+"/html/pages/redactivity/ios-course.html?flag=1&token="+this.token; // 非微信环境 进行跳转 
						}
					}
				}else{
					if (res.body.code === 305) {
						util.toast("获取红包信息失败！");
						return;
					}else{
		                if (res.body.code === 302) {
						  util.toast("太遗憾了，红包被领完了");
						  return;
		                }
		                if (res.body.code === 303) {
						  util.toast("当前人数过多，请稍后再试~");
						  return;
						}
						if (res.body.code === 300) {
							util.toast("您操作过于频繁");
							return;
						  }
						  if(res.body.msg){
							  util.toast(res.body.msg);
							  return;
						  }
					}
				}
			},(err)=>{
				console.log(err)
			})
			// $.get(proxypath+"/v1/envelopeActivity/notLoggedEnvelope",function(res){
			// 	console.log(res)
			// })
        },
        // 汇率转换
        rate(){
        	this.$http.post(proxypath+"/v1/envelopeActivity/tradingCurrency",{},
			{emulateJSON: true}
          	).then((res)=>{
          		console.log(res)
          		if (res.body.code===200) {
                       this.redrate=res.body.data;
          		}else{
          			if (res.body.msg) {
                         util.toast(res.body.msg)
          			}
          		}
          	},(err)=>{
          		console.log(err)
          	})
        },
        // 注册领取红包
        btnzce(){
        	window.location.href = proxypathone+"/html/pages/redactivity/red-register.html?giftId="+this.redshu.giftId+"&recommendCode="+recommendCode;
        }
	},
	filters:{
	}
})