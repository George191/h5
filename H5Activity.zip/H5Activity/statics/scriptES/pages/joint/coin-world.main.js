let uid=GB.utils.GetRequest()['uid']||'';
let recommendCode=GB.utils.GetRequest()['recommendCode']||'';
const vue = new Vue({
	el:"#coinworld",
	data:{
		uid:uid
	},
	created(){
	},
	mounted(){
        
	},
	methods:{
      tiao(){
      	window.location.href=basePath+"/html/pages/joint/world-premiere.html?&channelCode=bsj-register&uid="+this.uid+"&recommendCode="+recommendCode;
      }
	},
	filters:{

	}
})
