import {util} from '../../utils/util2.js'
import util1 from '../../utils/util1.js'
let channelCode=GB.utils.GetRequest()['channelCode']||'';
let recommendCode=GB.utils.GetRequest()['recommendCode']||'';

window.NVC_Opt = {
  //无痕配置 && 滑动验证、刮刮卡通用配置
  appkey: "FFFF0N0N000000006825",
  //appkey:'CF_APP_1',
  scene: "nvc_register_h5",
  isH5: true,
  popUp: false,
  renderTo: '#captcha',
  //trans: { "key1": "code0", "nvcCode": 400 }, //测试代码
  language: "cn",
  //滑动验证长度配置
  customWidth: 300,
  nvcCallback: function (data) {
    // data为getNVCVal()的值，此函数为二次验证滑动或者刮刮卡通过后的回调函数
	// data跟业务请求一起上传，由后端请求AnalyzeNvc接口，接口会返回100或者900
	var black_box = _fmOpt.getinfo();
    let param={
    	regName: vue.phone,
		password: vue.password,
		regType: 0,
		pcode:vue.msgCode,
		recommendCode:recommendCode,
		NVC:data,
		black_box:black_box,
		channelCode:channelCode
    }
    if (channelCode==="baa-register") {
		param.uid = vue.uid;
		param.userlevel = vue.level;
		param.sign = vue.sign;
	} else if (channelCode==="bsj-register") {
		param.uid = vue.uid;
	}else if (channelCode==="bitkeep-register") {
		param.address=vue.address;
		param.uid=vue.uid
	}else if (channelCode==="Fbee-register") {
	}
	try{
		Vue.http.post(
			proxypath+"/v1/regist/unitedplaythenewH5",
			 //"http://192.168.1.17:8086/v1/regist/unitedplaythenewH5",
			param,{emulateJSON:true})
		.then((res)=>{
			console.log(res)
			  if (res.body.code == 100 || res.body.code == 200) {
				  vue.isRegister = true;
				//注册成功
				that.zctrorfal = 2;
				vue.finished(2);
			  } else if (res.body.code == 800 || res.body.code == 900) {
				//直接拦截
				vue.isRegister = false;
				util.toast('请刷新页面后，重新注册');
			  } else {
				vue.isRegister = false;
				if (res.body.msg) {
				  util.toast(res.body.msg)
				}
			  }
		},(err)=>{
			//alert(err);
		})
	} catch(err){
		console.log(err);
	}
	
  }
}




var vue = new Vue({
	el:"#world",
	data:{
		phone:"",
		password:"",
		msgCode:"",
		msgText:"获取验证码",
		xuan:true,
		channelCode:channelCode,
		isSendMsg:false,
		zctrorfal:0,//控制注册成功后显示
		uid:"",
		uuid:'',
		level:"",
		mail:"",
		sign:"",
		reply:'',
		address:'', // bitkeep返回的地址
		isRegister:false,
		cloudShow:false,  //控制滑块是否显示
		open:false, //控制活动是否开启图片
		disabled: false,
		settims:0
	},
	created(){
		util1.loadJs('//g.alicdn.com/sd/nvc/1.1.112/guide.js?random=' + Math.random());
		this.finished();
	},
	mounted(){
		var that=this;
	 // 比牛牛 要携带的参数:邀请码、UserID、userlevel、签名(由我方提供) 手机号或邮箱
        if (channelCode==="baa-register") {
			  document.title='bitget&币牛牛会员福利';
        	  let uid=GB.utils.GetRequest()['uid']||'';
	          let level=GB.utils.GetRequest()['level']||'';
	          let phone=GB.utils.GetRequest()['phone']||'';
	          let sign=GB.utils.GetRequest()['sign']||'';
	          // 手机号码	         
				if(phone){
					this.phone=phone;
					 this.$nextTick(()=>{
						this.disabled=true;
					 })                   
				}
              this.uid=uid
              this.level=level
              this.sign=sign
        }else if (channelCode==="bsj-register") {
			document.title='bitget&币世界会员福利';  
			let uuid=GB.utils.GetRequest()['uuid']||'';
              this.uuid=uuid;
		}else if(channelCode==="bitkeep-register"){ // bitkeep
			document.title='bitget&BitKeep会员福利'; 
			  jhost('getWalletAddress','eth',function(err,reply){
				if(reply){
				   var data=reply.split(',');
				   var address=data[0];
				   var uid=data[1];
				   // alert(address);
				   // alert(uid);
				   that.address=address;
				   that.uid=uid;
				}
				that.reply=reply;
			})
        } else if(channelCode==="Fbee-register"){
          document.title="bitget&Fbee会员福利";
		}
	},
	methods:{
		// 勾选
        gouxuan(){
        	this.xuan=!this.xuan
        },
        validGouxuan(){
        	if (!this.xuan) {
        		util.toast("请先同意并勾选用户协议")
        		return false
        	}
        	return true
        },
        // 手机号
        validLoginName() {
	        //手机
	       if (this.phone === "") {
	        util.toast("请输入手机号")
	         return
	        }
	        if (!(util.telReg.test(this.phone))) {
	          util.toast("您输入的手机号码格式有误")
	          return false;
	        }
	      
	      return true;
	    },
	    // 密码
	    validpwd(){
    	  if (this.password.length===0) {
    		 util.toast("请设置密码")
    		 return false;
    	  }
	      if (!(util.pwdReg.test(this.password))) {
	       util.toast("密码需包含字母、数字或特殊字符且长度在6~32位")
	        return false;
	      }
	      if (this.password.length < 6) {
	        util.toast("密码需包含字母、数字或特殊字符且长度在6~32位")
	        return false;
	      } 
	      return true
	    },
        // 获取验证码
        sendMsg(){
        	if (this.isSendMsg) {
	          	return false;
	        }
	        // 手机号
        	if (!this.validLoginName()) {
        		return false;
        	}
        	// 密码
        	if (!this.validpwd()) {
        		return false;
        	}
          	this.settims = util.tickerCountDown(60, 1000, (sec)=>{
                  	if (sec>0) {
                  		this.msgText = sec + "s";
                  	}else{
  					    this.msgText = "重新获取";
  					    this.isSendMsg = false;
                  }
            })
            this.isSendMsg=true;
	        let param = {
	        		type: 11,
	                msgtype: 1,
			        phone: this.phone,
			        userId: "",
	                areaCode: "86"
	            }
	        this.$http.post(proxypath+"/v1/send/regist_send_phone",param,{emulateJSON:true})
	        .then((res)=>{
	        	console.log(res)
	        	if (res.body.code===200) {
	        		this.isSendMsg=true;
               //    	this.settims = util.tickerCountDown(60, 1000, (sec)=>{
               //        	if (sec>0) {
               //        		this.msgText = sec + "s";
               //        	}else{
      					    // this.msgText = "重新获取";
      					    // this.isSendMsg = false;
               //        }
               //       })
	        	}else{
	        		this.isSendMsg=false;
        			if (res.body.msg) {
        				util.toast(res.body.msg);
        			}
	        	}
	        },(err)=>{
	        	console.log(err)
	        })    
        },
        validMsgCode() {
	        if (this.msgCode.length === 0) {
	          util.toast("请输入短信验证码")
	          return false;
	        }
	        if (this.msgCode.length < 6) {
	          util.toast("短信验证码格式错误,请重新输入")
	          return false;
	        }
	        console.log(this.msgCode)
	        return true
	    },
	    // 注册
        register(){

        	if (this.isRegister) {
	          	return false;
	        }
	        // 手机号
        	if (!this.validLoginName()) {
        		return false
        	}
        	// 密码
        	if (!this.validpwd()) {
        		return false
        	}
        	// 短信验证码
        	if (!this.validMsgCode()) {
        		return false
        	}
        	
        	// 勾选
	        if (!this.validGouxuan()) {
	        	return false;
	        }
	        this.isRegister = true;
			var black_box = _fmOpt.getinfo();
			//console.log(black_box);
	        let param={
	        	regName: this.phone,
				password: this.password,
				pcode:this.msgCode,
				regType: 0,
				recommendCode:recommendCode,
				black_box:black_box,
				channelCode:channelCode
			}
            // 添加人机验证的代码

    	  	let nvcMsg = getNVCVal();

      	  	param.NVC = nvcMsg;
	        if (channelCode==="baa-register") {
				param.uid = this.uid;
				param.userlevel = this.level;
				param.regName = this.phone;
				param.sign = this.sign;
			} else if (channelCode==="bsj-register") {
				param.uuid = this.uuid;
			}else if (channelCode==="bitkeep-register") {
				param.address=this.address;
				param.uid=this.uid;
			}else if (channelCode==="Fbee-register") {
			}
			var that = this;
			that.$http.post(
				proxypath+"/v1/regist/unitedplaythenewH5",
				 //"http://192.168.1.17:8086/v1/regist/unitedplaythenewH5",
				param,
				{emulateJSON:true}
				).then((res)=>{
				console.log(res)
	            if (res.body.code == 400 || res.body.code == 600) {
		            that.cloudShow=true;
		            //唤醒滑动验证
		            getNC().then(function () {
		              NoCaptcha.upLang('cn', {
		                'LOADING': "加载中...",//加载
		                'SLIDER_LABEL': "请按住滑块，滑动到最右边",//等待滑动
		                'CHECK_Y': "验证通过",//通过
		                'ERROR_TITLE': "哎呀，出错了，点击<a href=\"javascript:NoCaptcha.reset()\">刷新</a>再来一次",//拦截
		                'CHECK_N': "验证未通过", //准备唤醒二次验证
		                'OVERLAY_INFORM': "经检测你当前操作环境存在风险，请输入验证码",//二次验证
		                'TIPS_TITLE': "验证码错误，请重新输入",//验证码输错时的提示
		                '_errorNetwork': "网络不给力，请<a href=\"javascript:NoCaptcha.reset()\">点击刷新</a>",
		              });
		              _nvc_nc.reset();
		            })
		          } else if (res.body.code == 100 || res.body.code == 200) {
		            //注册成功
		            that.zctrorfal = 2;
					that.finished(2); //第二次确认 是否已经结束
					window.scrollTo(0,0);

		          } else if (res.body.code == 800 || res.body.code == 900) {
		            //直接拦截
		            that.isRegister = false;
		            util.toast('请刷新页面后，重新注册');
		          } else {
		            that.isRegister = false;
		            if (res.body.msg) {
		              util.toast(res.body.msg)
		            }
		          }
			},(err)=>{
				console.log(err)
			})
        },
        // 活动结束
        finished(type){
        	this.$http.post(
        		proxypath+"/v1/unitedPlayTheNew/unitedPlayTheNewFacadeStatus",
        		{activeCode:recommendCode},
        		{emulateJSON:true}
        		).then((res)=>{
        			if (res.body.code===200) {
						  if(!type){
							this.zctrorfal=1;
							this.open=true
						  } else{
							this.open=true
						  }						 
        			}else if (res.body.code===300) {
						//util.toast('活动未开启');
						this.open=false;
        				this.zctrorfal = 2;
        				
        			}
        		},(err)=>{
        			console.log(err)
        		})
        },


        // 复制下载链接
        copybord(){
        	
        var clipboard = new ClipboardJS('.er-btn')
        clipboard.on('success', e => {
          util.toast("复制链接成功")
          // 释放内存
          clipboard.destroy()
        })
        clipboard.on('error', e => {
          // 不支持复制
          console.log('该浏览器不支持自动复制')
          // 释放内存
          clipboard.destroy()
        })
      //   	var textArea = document.createElement("textarea")

		    // textArea.style.position = 'fixed'
		    // textArea.style.top = 0
		    // textArea.style.left = 0
		    // textArea.style.width = '2em'
		    // textArea.style.height = '2em'
		    // textArea.style.padding = 0
		    // textArea.style.border = 'none'
		    // textArea.style.outline = 'none'
		    // textArea.style.boxShadow = 'none'
		    // textArea.style.background = 'transparent'
		    // textArea.value = text

		    // document.body.appendChild(textArea)

		    // textArea.select()

		    // try {
		    //   var msg = document.execCommand('copy') ? util.toast("复制链接成功"): util.toast("复制链接失败")
		    //   // console.log('复制内容 ' + msg)
		    // } catch (err) {
		    //   console.log('不能使用这种方法复制内容')
		    // }

		    // document.body.removeChild(textArea)
        }
	},
	filters:{

	}
})
