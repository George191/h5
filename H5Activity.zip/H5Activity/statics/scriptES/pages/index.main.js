//公共代码示例 


var  params=GB.utils.GetRequest()['params'];
var  token=GB.utils.GetRequest()['token'];
if(params){
    alert(params);
    try{
     var paramObj=JSON.parse(params);
      alert(paramObj.key);
    } catch(err){

    }
}
if(token){
    alert(token);
}


var vue= new Vue({
    el:'#app',
    data:{

    },
    methods:{
        dialog(){

             var  html=$("#dialog-template").html();

             GB.utils.showhtml({
                 content:html,
                 eventHandler(){
                    var $boudingBox=this.boudingBox;

                    //函数内部的 this  是 这个 dialog对象 

                    var that=this;
                    $boudingBox.on("click",'.sure-btn',function(){
                     
                         alert('点击确认');
                         
                         that.destroy();



                    })
                 }
             })

        },
        tologin(){
            //send('goLogin',{key:1});
            var param={key:1};
            GB.utils.goLogin(param);
        },
        goCapital(){
            GB.utils.goCapital({});
        }
    }
})