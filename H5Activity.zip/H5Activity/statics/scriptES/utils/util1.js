const util = {
  /**
   * 消息消失框
   */
  toast(msg = '', time = 1500) {
    var toast = document.createElement('div')
    toast.className = 'common-toast common-toast-show'
    toast.innerHTML = msg
    document.body.appendChild(toast)
    toast.style.display = 'block';
    var timer = setTimeout(() => {
      toast.className = 'common-toast common-toast-hide'
      clearTimeout(timer)
      var timer2 = setTimeout(() => {
        document.body.removeChild(toast)
        clearTimeout(timer2)
      }, 200)
    }, time)
  },
  /**验证方法**/
  valid: {
    checkTelephone(telephone) {
      if (!telephone) {
        util.toast('请输入手机号码');
        return false
      }
      if (!/1[3457869]\d{9}/.test(telephone) || telephone.length != 11) {
        util.toast('手机号格式错误');
        return false
      }
      return true;
    },
    checkPassword(password) {
      if (!password) {
        util.toast('密码不能为空');
        return false
      }
      if (!/[0-9]{6}/.test(password)) {
        util.toast('密码格式不正确');
        return false
      }
      return true;
    },
    checkYzm(yzm) {
      if (!yzm) {
        util.toast('请输入短信验证码');
        return false
      }
      if (!/^\d{6}$/.test(yzm)) {
        util.toast('验证码格式错误');
        return false
      }
      return true;
    },
    checkIdCard(idcard) {
      var reg = /^[1-9][0-7]\d{4}((19\d{2}(0[13-9]|1[012])(0[1-9]|[12]\d|30))|(19\d{2}(0[13578]|1[02])31)|(19\d{2}02(0[1-9]|1\d|2[0-8]))|(19([13579][26]|[2468][048]|0[48])0229))\d{3}(\d|X|x)?$/;
      if (!reg.test(idcard)) {
        util.toast('身份证格式不正确');
        return false;
      }
      return true
    },
    notEmpty(param, title) {
      if (!param) {
        util.toast(title + '不能为空');
        return false
      }
      return true
    },
    isInt(v, title) {
      if (parseFloat(v) < 1 || v.indexOf('.') > -1) {
        return false
      }
      return true;
    },
    limitNumber(num, s) {
      var regparam = "(^[0-9]([0-9]+)?(\\.[0-9]{0," + s + "})?$)";
      var reg = new RegExp(regparam);
      if (!reg.test(num)) {
        return false
      }
      return true
    }
  },
  qs(obj) {
    return obj;
  },
  toCent(num) {
    var numReal;
    try {
      numReal = parseFloat(num);
    } catch (e) {
      return 0;
    }
    var numStr = numReal + '';
    if (typeof (numReal) !== 'number' || numStr.length === 0 || num === '0' || num === 0) return 0;
    var decLength = 0;
    try {
      decLength = numStr.split('.')[1].length;
    } catch (e) { }
    numStr = numStr.replace('.', '');
    numStr = parseInt(numStr);
    if (decLength === 0) return numStr * 100;
    if (decLength == 1) return numStr + '0';
    if (decLength == 2) return numStr
  },
  clearNumber(value, num) {
    var num = num || 2;
    var value = value.replace(/[^\d.]/g, ""); // 清除“数字”和“.”以外的字符
    while (value && value[0] == '.') {
      value = value.replace(/^\./g, ""); // 验证第一个字符是数字而不是.
    }

    value = value.match(/(.{0,12})/g)[0];
    value = value.replace(/\.{2,}/g, "."); // 只保留第一个. 清除多余的
    value = value.replace(".", "$#$").replace(/\./g, "").replace("$#$", ".");
    value = value.replace(new RegExp("^(\\-)*(\\d+)\\.(\\d{0," + num + "}).*$", "gmi"), '$1$2.$3');
    return value;
  },
  isIE() {
    var Sys = {};
    var ua = navigator.userAgent.toLowerCase();
    var s;
    (s = ua.match(/rv:([\d.]+)\) like gecko/)) ? Sys.ie = s[1] :
      (s = ua.match(/msie ([\d.]+)/)) ? Sys.ie = s[1] : 0;
    if (Sys.ie) {
      return true;
    } else {
      return false;
    }


  },
  trim(s) {
    return s.replace(/^\s+|\s+$/gm, '');
  },
  dateReplace(s) {
    return s.replace(/\-/g, '\/')
  },
  browser: (function () {
    var u = navigator.userAgent, app = navigator.appVersion;
    return {// 移动终端浏览器版本信息
      trident: u.indexOf('Trident') > -1, // IE内核
      presto: u.indexOf('Presto') > -1, // opera内核
      webKit: u.indexOf('AppleWebKit') > -1, // 苹果、谷歌内核
      gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1, // 火狐内核
      mobile: !!u.match(/AppleWebKit.*Mobile.*/) || !!u.match(/AppleWebKit/), // 是否为移动终端
      ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), // ios终端
      android: u.indexOf('Android') > -1 || u.indexOf('Linux') > -1, // android终端或者uc浏览器
      iPhone: u.indexOf('iPhone') > -1 || u.indexOf('Mac') > -1, // 是否为iPhone或者QQHD浏览器
      iPad: u.indexOf('iPad') > -1, // 是否iPad
      webApp: u.indexOf('Safari') == -1
      // 是否web应该程序，没有头部与底部
    };
  })(),
  loadJs: function (url, cb) {
    var script = document.createElement('script');

    script.type = "text/javascript";
    if (typeof (cb) != "undefined") {
      if (script.readyState) {
        script.onreadystatechange = function () {
          if (script.readyState == "loaded" || script.readyState == "complete") {
            script.onreadystatechange = null;
            if (cb) {
              cb();
            }
          }
        }

      } else {
        script.onload = function () {
          if (cb) {
            cb();
          }
        }
      }
    }
    script.src = url;
    document.body.appendChild(script);
  },
  NVC_Opt_register() {
    //无痕验证
    window.NVC_Opt = {
      //无痕配置 && 滑动验证、刮刮卡通用配置
      appkey: "FFFF0N0N000000006825",
      //appkey:'CF_APP_1',
      scene: "nvc_register_h5",
      isH5: true,
      popUp: false,
      renderTo: '#captcha',
      //trans: { "key1": "code0", "nvcCode": 400 }, //测试代码
      language: "cn",
      //滑动验证长度配置
      customWidth: 300,
      nvcCallback: function (data) {
        // data为getNVCVal()的值，此函数为二次验证滑动或者刮刮卡通过后的回调函数
        // data跟业务请求一起上传，由后端请求AnalyzeNvc接口，接口会返回100或者900
        alert(1);
      }
    }
  },
  NVC_Opt_sec(cb){
    //二次验证配置
    getNC().then(function(){
      NoCaptcha.upLang('cn', {
          'LOADING':"加载中...",//加载
          'SLIDER_LABEL': "请按住滑块，滑动到最右边",//等待滑动
          'CHECK_Y':"验证通过",//通过
          'ERROR_TITLE':"哎呀，出错了",//拦截
          'CHECK_N':"验证未通过", //准备唤醒二次验证
          'OVERLAY_INFORM':"经检测你当前操作环境存在风险，请输入验证码",//二次验证
          'TIPS_TITLE':"验证码错误，请重新输入",//验证码输错时的提示
          '_errorNetwork': "网络不给力，请<a href=\"javascript:NoCaptcha.reset()\">点击刷新</a>",
      });
      //NoCaptcha.reset();
      _nvc_nc.reset();
      //$("#nc_1-stage-3").html('<div onclick="NoCaptcha.reset()" >出错了</div>');
      if(cb){
        cb();
      }
  })
    
  }
}
export default util
