let util = {
	// 消息提示框
  toast(msg = '', time = 1500) {
    var toast = document.createElement('div')
    toast.className = 'common-toast common-toast-show'
    toast.innerHTML = msg
    document.body.appendChild(toast)
    toast.style.display = 'block';
    var timer = setTimeout(() => {
      toast.className = 'common-toast common-toast-hide'
      clearTimeout(timer)
      var timer2 = setTimeout(() => {
        document.body.removeChild(toast)
        clearTimeout(timer2)
      }, 200)
    }, time)
  },
  emailReg: /^([a-zA-Z0-9_\-\.\+]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/,
  // telReg: /^[0-9]*$/,
  telReg: /(^1[3|4|5|7|8]\d{9}$)|(^09\d{8}$)/,
  pwdReg: /^(?![0-9]+$)(?![a-zA-Z]+$)[\S]{6,}$/,
  // serverUrl: "http://www.upex.com:8081",
  serverUrl: "",//http://local.upex.com:8082
  objToUrl(obj) {
    if (!obj) {
      return '';
    }
    let params = [];
    for (const key in obj) {
      if (obj.hasOwnProperty(key)) {
        const element = obj[key];
        params.push(encodeURIComponent(key) + '=' + encodeURIComponent((element === undefined ? '' : element)));
      }
    }
    return params.join("&");
  },
  fetch(path, opt) {
    try {
      opt = typeof opt === "undefined" ? {} : opt;
      const request = new Request(util.serverUrl + path, {
        method: opt.method === undefined ? "POST" : opt.method,
        body: util.objToUrl(opt.param),
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        credentials: "include"
      });
      return fetch(request).then(data => data.json());
    } catch (e) {
      console.log("Oops, error", e);
      return {
        code: '-1',
        msg: '服务器异常'
      }
    }
  },
   ajax(path,opt){
       opt = typeof opt === "undefined" ? {} : opt;
        return  $.ajax({
           url:util.serverUrl+path,
           data:opt.data,
           method:opt.method === undefined ? "post" : opt.method
       })
   },
    ajax2(path,opt){
        opt = typeof opt === "undefined" ? {} : opt;
        return  $.ajax({
            url:util.serverUrl+path,
            data:opt.data,
            method:opt.method === undefined ? "post" : opt.method
        }).done((res)=>{

            var r=JSON.parse(res);
            if(r.code===200){
                $.Deferred.resolve(r);
            } else{
               if(r.msg){
                   BT.util.info(r.msg);
               }
               $.Deferred.reject(r);
            }
        }).fail((err)=>{
             BT.util.info('网络错误，请稍后重试')
        })
    },
  initNECaptcha(opt) {
    let capchaIds = {
      "login": "eaa8e3b53e6b4505b4f090daae06806d",
      "register": "646c1148376d47299b31315f53956996",
      "forget": "7e40c11173af4301a50cd23acc39b845",
      "bind-google": "31995ce1d5454c3c87dc64f998db0e20",
      "unbind-google": "31995ce1d5454c3c87dc64f998db0e20",
      "update-google": "31995ce1d5454c3c87dc64f998db0e20",
      "bind-phone": "d8148e2664dd41c0bfdc43751f9db9b3",
      "unbind-phone": "d8148e2664dd41c0bfdc43751f9db9b3",
      "update-phone": "d8148e2664dd41c0bfdc43751f9db9b3",
      "bind-email": "b2d47506fe0546efa95420d957f530d1",
      "virtual-withdraw": "24e85d9ee7c54e48a0404e974778ed34",
      "virtual-withdraw-account": "24e85d9ee7c54e48a0404e974778ed34"
    };
    window.initNECaptcha = window.initNECaptcha ? window.initNECaptcha : initNECaptcha;
    initNECaptcha({
      captchaId: capchaIds[opt.captchaId], // <-- 这里填入在易盾官网申请的验证码id
      element: opt.target,
      mode: opt.mode !== undefined ? opt.mode : "float",
      onVerify: opt.onVerify
    }, opt.onInit, opt.onError);
  },
  tickerCountDown(second, timeout, callback) {
    let s = second;
    if (timeout === undefined) {
      timeout = 1000;
    }
    let intervalId = setInterval(() => {
      s--;
      if (s === 0) {
        clearInterval(intervalId);
        callback(-1);
      } else {
        callback(s);
      }
    }, 1000);
    return intervalId
  }
};

let msg = {
  sendMsg(sendType, msgType, address, vcode, userId, areaCode) {
    let param, url;
    if (sendType === 0) {
      //短信
      url = "/v1/send/regist_send_phone";
      param = {
        type: msgType,
        msgtype: 1,
        phone: address,
        NECaptchaValidate: vcode,
        userId: userId,
        areaCode: areaCode === undefined ? "86" : areaCode
      };
    } else if (sendType === 1) {
      //邮箱
      url = "/v1/send/regist_send_email";
      param = {
        type: msgType,
        msgtype: 1,
        address: address,
        NECaptchaValidate: vcode,
        userId: userId
      };
    }

    return util.fetch(url, {
      param: param
    });
  }
};

window.util = window.util || util;
window.msg = window.msg || msg;

/**
 * Checks if the given string is an address
 *
 * @method isAddress
 * @param {String} address the given HEX address
 * @return {Boolean}
 */
function isAddress(address) {
  console.log("isAddress:", address);
  // check if it has the basic requirements of an address
  if (!/^(0x)[0-9a-f]{40}$/i.test(address)) {
    return false;
    // If it's ALL lowercase or ALL upppercase
  } else if (/^(0x|0X)[0-9a-f]{40}$/.test(address) || /^(0x|0X)[0-9A-F]{40}$/.test(address)) {
    return true;
    // Otherwise check each case
  } else {
    return checkAddressChecksum(address);
  }
}


/**
 * Checks if the given string is a checksummed address
 *
 * @method checkAddressChecksum
 * @param {String} address the given HEX address
 * @return {Boolean}
 */
function checkAddressChecksum(address) {
  // Check each case
  address = address.replace(/^0x/i, '');
  let addressHash = sha3(address.toLowerCase()).replace(/^0x/i, '');

  for (let i = 0; i < 40; i++) {
    // the nth letter should be uppercase if the nth digit of casemap is 1
    if ((parseInt(addressHash[i], 16) > 7 && address[i].toUpperCase() !== address[i]) || (parseInt(addressHash[i], 16) <= 7 && address[i].toLowerCase() !== address[i])) {
      return false;
    }
  }
  return true;
}

/**
 * Hashes values to a sha3 hash using keccak 256
 *
 * To hash a HEX string the hex must have 0x in front.
 *
 * @method sha3
 * @return {String} the sha3 string
 */
const SHA3_NULL_S = '0xc5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470';

function sha3(value) {
  if (isHexStrict(value) && /^0x/i.test((value).toString())) {
    value = hexToBytes(value);
  }

  let returnValue = Hash.keccak256(value); // jshint ignore:line

  if (returnValue === SHA3_NULL_S) {
    return null;
  } else {
    return returnValue;
  }
}

/**
 * Check if string is HEX, requires a 0x in front
 *
 * @method isHexStrict
 * @param {String} hex to be checked
 * @returns {Boolean}
 */
function isHexStrict(hex) {
  return ((_.isString(hex) || _.isNumber(hex)) && /^(-)?0x[0-9a-f]*$/i.test(hex));
}

function hexToBytes(hex) {
  hex = hex.toString(16);

  if (!isHexStrict(hex)) {
    throw new Error('Given value "' + hex + '" is not a valid hex string.');
  }

  hex = hex.replace(/^0x/i, '');
  let bytes = [], c = 0;
  for (; c < hex.length; c += 2) {
    bytes.push(parseInt(hex.substr(c, 2), 16));
  }
  return bytes;
}


export {msg, util, isAddress};
