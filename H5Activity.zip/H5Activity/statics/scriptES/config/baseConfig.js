/**
 * Created by ckid_hjqb on 2017/7/11.
 */

export const DEV_USER_PRIVILEGE_URL = 'https://dev.huangjinqianbao.com/privilege/index';
export const USER_PRIVILEGE_URL = 'http://static02.huangjinqianbao.com/static/html/app/privilege/index';
