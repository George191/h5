
//在这里判断各页面 音乐播放的实现

$(function(){

    // var $audio=$("#J_audio");
    // var audio= new Audio(imgUrl+'/cupdraw.mp3');
    // audio.loop=true;
    // var audiostatus=true;
    // setTimeout(function(){
    //    audio.play()
    // },800)
    // $audio.on("click",function(){
    //     audiostatus=!audiostatus;
    //     localStorage.setItem('cupdrawstatus',audiostatus);
    //     if(audiostatus){
    //         $(this).removeClass('off');
    //         audio.play();
    //       } else{
    //         $(this).addClass('off');
    //         audio.pause();
    //       }
    // })

})