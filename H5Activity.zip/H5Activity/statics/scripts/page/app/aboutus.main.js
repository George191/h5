(function () {
'use strict';

var vue = new Vue({
							el: ".aboutus",
							data: {
														// cxian1:false,
														// cxian2:false
							},
							mounted: function mounted() {},

							methods: {
														dian: function dian(index) {
																					// if (index==="4") {
																					// 	this.cxian=!this.cxian
																					// }
																					switch (index) {
																												case "1":
																																			this.$router.push({ path: "/html/pages/app/User-protocol.html" });
																																			// this.cxian1=!this.cxian1
																																			// this.cxian2=false
																																			break;
																												default:
																																			this.$router.push({ path: "/html/pages/app/Version.html" });
																												// this.cxian2=!this.cxian2
																												//   this.cxian1=false
																					}
														}
							},
							filters: {}
});

}());

//# sourceMappingURL=aboutus.main.js.map

//# sourceMappingURL=aboutus.main.js.map
