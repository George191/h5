(function () {
'use strict';

var util = {
  // 消息提示框
  toast: function toast() {
    var msg = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
    var time = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1500;

    var toast = document.createElement('div');
    toast.className = 'common-toast common-toast-show';
    toast.innerHTML = msg;
    document.body.appendChild(toast);
    toast.style.display = 'block';
    var timer = setTimeout(function () {
      toast.className = 'common-toast common-toast-hide';
      clearTimeout(timer);
      var timer2 = setTimeout(function () {
        document.body.removeChild(toast);
        clearTimeout(timer2);
      }, 200);
    }, time);
  },

  emailReg: /^([a-zA-Z0-9_\-\.\+]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/,
  // telReg: /^[0-9]*$/,
  telReg: /(^1[3|4|5|7|8]\d{9}$)|(^09\d{8}$)/,
  pwdReg: /^(?![0-9]+$)(?![a-zA-Z]+$)[\S]{6,}$/,
  // serverUrl: "http://www.upex.com:8081",
  serverUrl: "", //http://local.upex.com:8082
  objToUrl: function objToUrl(obj) {
    if (!obj) {
      return '';
    }
    var params = [];
    for (var key in obj) {
      if (obj.hasOwnProperty(key)) {
        var element = obj[key];
        params.push(encodeURIComponent(key) + '=' + encodeURIComponent(element === undefined ? '' : element));
      }
    }
    return params.join("&");
  },
  fetch: function (_fetch) {
    function fetch(_x3, _x4) {
      return _fetch.apply(this, arguments);
    }

    fetch.toString = function () {
      return _fetch.toString();
    };

    return fetch;
  }(function (path, opt) {
    try {
      opt = typeof opt === "undefined" ? {} : opt;
      var request = new Request(util.serverUrl + path, {
        method: opt.method === undefined ? "POST" : opt.method,
        body: util.objToUrl(opt.param),
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        credentials: "include"
      });
      return fetch(request).then(function (data) {
        return data.json();
      });
    } catch (e) {
      console.log("Oops, error", e);
      return {
        code: '-1',
        msg: '服务器异常'
      };
    }
  }),
  ajax: function ajax(path, opt) {
    opt = typeof opt === "undefined" ? {} : opt;
    return $.ajax({
      url: util.serverUrl + path,
      data: opt.data,
      method: opt.method === undefined ? "post" : opt.method
    });
  },
  ajax2: function ajax2(path, opt) {
    opt = typeof opt === "undefined" ? {} : opt;
    return $.ajax({
      url: util.serverUrl + path,
      data: opt.data,
      method: opt.method === undefined ? "post" : opt.method
    }).done(function (res) {

      var r = JSON.parse(res);
      if (r.code === 200) {
        $.Deferred.resolve(r);
      } else {
        if (r.msg) {
          BT.util.info(r.msg);
        }
        $.Deferred.reject(r);
      }
    }).fail(function (err) {
      BT.util.info('网络错误，请稍后重试');
    });
  },
  initNECaptcha: function (_initNECaptcha) {
    function initNECaptcha(_x5) {
      return _initNECaptcha.apply(this, arguments);
    }

    initNECaptcha.toString = function () {
      return _initNECaptcha.toString();
    };

    return initNECaptcha;
  }(function (opt) {
    var capchaIds = {
      "login": "eaa8e3b53e6b4505b4f090daae06806d",
      "register": "646c1148376d47299b31315f53956996",
      "forget": "7e40c11173af4301a50cd23acc39b845",
      "bind-google": "31995ce1d5454c3c87dc64f998db0e20",
      "unbind-google": "31995ce1d5454c3c87dc64f998db0e20",
      "update-google": "31995ce1d5454c3c87dc64f998db0e20",
      "bind-phone": "d8148e2664dd41c0bfdc43751f9db9b3",
      "unbind-phone": "d8148e2664dd41c0bfdc43751f9db9b3",
      "update-phone": "d8148e2664dd41c0bfdc43751f9db9b3",
      "bind-email": "b2d47506fe0546efa95420d957f530d1",
      "virtual-withdraw": "24e85d9ee7c54e48a0404e974778ed34",
      "virtual-withdraw-account": "24e85d9ee7c54e48a0404e974778ed34"
    };
    window.initNECaptcha = window.initNECaptcha ? window.initNECaptcha : initNECaptcha;
    initNECaptcha({
      captchaId: capchaIds[opt.captchaId], // <-- 这里填入在易盾官网申请的验证码id
      element: opt.target,
      mode: opt.mode !== undefined ? opt.mode : "float",
      onVerify: opt.onVerify
    }, opt.onInit, opt.onError);
  }),
  tickerCountDown: function tickerCountDown(second, timeout, callback) {
    var s = second;
    if (timeout === undefined) {
      timeout = 1000;
    }
    var intervalId = setInterval(function () {
      s--;
      if (s === 0) {
        clearInterval(intervalId);
        callback(-1);
      } else {
        callback(s);
      }
    }, 1000);
    return intervalId;
  }
};

var msg = {
  sendMsg: function sendMsg(sendType, msgType, address, vcode, userId, areaCode) {
    var param = void 0,
        url = void 0;
    if (sendType === 0) {
      //短信
      url = "/v1/send/regist_send_phone";
      param = {
        type: msgType,
        msgtype: 1,
        phone: address,
        NECaptchaValidate: vcode,
        userId: userId,
        areaCode: areaCode === undefined ? "86" : areaCode
      };
    } else if (sendType === 1) {
      //邮箱
      url = "/v1/send/regist_send_email";
      param = {
        type: msgType,
        msgtype: 1,
        address: address,
        NECaptchaValidate: vcode,
        userId: userId
      };
    }

    return util.fetch(url, {
      param: param
    });
  }
};

window.util = window.util || util;
window.msg = window.msg || msg;

var defineProperty = function (obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
};

var vue = new Vue(defineProperty({
    el: ".pucket-activity",
    data: {
        urls: "",
        tokens: "",
        conversion: "",
        packetnum: 0,
        errmsg: "1",
        nologgiftId: "",
        czrewardCoin: "",
        rewardCoin: "",
        czcoinCode: "",
        coinCode: "",
        recelist: [],
        wlogin: 1,
        logstatus: false,
        lingmsg: false,
        logipack: false,
        rechargemsg: false,
        chongzhi: false,
        terminalType: "",
        arr: []
    },
    created: function created() {
        // alert("111");
        var _this = this;
        var params = GB.utils.GetRequest()['params'];
        var token = GB.utils.GetRequest()['token'];
        this.urls = params;
        this.tokens = token;
        console.log(this.tokens);
        if (params) {
            params = JSON.parse(params);
        }
        this.logstatus = token ? true : false;
        console.log(this.logstatus);

        if (GB.utils.getPlatform() === "android") {
            this.terminalType = 2;
        } else {
            this.terminalType = 3;
        }

        if (this.logstatus) {
            var obj = {};
            if (params) {
                obj = {
                    activeCode: "receiveGiftAct",
                    token: _this.tokens,
                    giftId: params.giftId,
                    appVersion: "1",
                    charset: "UTF8",
                    language: "zh",
                    terminalCode: "WEB",
                    terminalType: _this.terminalType,
                    terminalVersion: "1",
                    version: "1.0"
                };
            } else {
                obj = {
                    activeCode: "receiveGiftAct",
                    token: _this.tokens,
                    appVersion: "1",
                    charset: "UTF8",
                    language: "zh",
                    terminalCode: "WEB",
                    terminalType: _this.terminalType,
                    terminalVersion: "1",
                    version: "1.0"
                };
            }

            // 查询绑定红包
            this.$http.post(appproxypath + "/app/v2/envelopeActivity/userHaveToReceiveApp", obj, { emulateJSON: true }).then(function (response) {
                var res = JSON.parse(response.body);
                console.log(res);
                if (res.code === "00000") {
                    if (res.data.userRewardResult.rewardList.length > 0) {
                        var datas = res.data.userRewardResult.rewardList;
                        datas.forEach(function (item) {
                            // rewardType 1:注册红包 2：充值红包
                            if (item.rewardType === 1) {
                                _this.packetnum += 1;
                                //改变红包图片为拆包
                                _this.wlogin = 2;
                                // 赋值单位
                                _this.rewardCoin = item.rewardCoin;
                                //giftId
                                // _this.nologgiftId = res.data.receiveGiftResult.giftId;
                                // 赋值红包大小
                                _this.coinCode = item.coinCode;
                            }
                            if (item.rewardType === 2) {
                                _this.packetnum += 1;
                                _this.chongzhi = true;
                                // 赋值单位
                                _this.czrewardCoin = item.rewardCoin;
                                // 赋值红包大小
                                _this.czcoinCode = item.coinCode;
                            }
                        });
                    }
                } else {
                    if (res.msg) {
                        GB.utils.toast(res.msg);
                    }
                }
            }, function (err) {
                console.log(err);
            });
        }

        // 红包记录  proxypath
        $.post(appproxypath + "/app/v2/envelopeActivity/getAfterLoginReceiveRedEnvelopeAll", {
            activeCode: "receiveGiftAct",
            appVersion: "1",
            charset: "UTF8",
            language: "zh",
            terminalCode: "WEB",
            terminalType: _this.terminalType,
            terminalVersion: "7.0",
            version: "1.0"
        }, function (res) {
            var datas = JSON.parse(res);
            if (datas.code === "00000") {
                _this.recelist = datas.data.rewardItem;
            }
        });

        $.post(appproxypath + "/app/v2/envelopeActivity/tradingCurrency", function (res) {
            var datas = JSON.parse(res);
            if (datas.code === 200) {
                console.log(datas);
                _this.conversion = datas.data;
                console.log(_this.conversion);
            }
        });
    },

    filters: {
        converfun: function converfun(val) {
            var number = val * this.conversion;
            var retval = number.toFixed(2);
            return retval;
        }
    },
    mounted: function mounted() {},

    methods: {
        gozich: function gozich() {
            GB.utils.goCapital({});
        },

        // 跳转登录
        recebtn: function recebtn() {
            var param = { giftId: this.nologgiftId };
            GB.utils.goLogin(param);
        },

        // 跳转推荐返佣
        gorecommend: function gorecommend() {
            GB.utils.getReward({});
        },

        // 注册红包领取
        chaipuckbtn: function chaipuckbtn() {
            var _this = this;

            if (!this.logstatus) {
                // 点击红包接口
                this.$http.post(appproxypath + "/app/v2/envelopeActivity/notLoggedEnvelope", {
                    activeCode: "receiveGiftAct",
                    appVersion: "1",
                    charset: "UTF8",
                    language: "zh",
                    terminalCode: "WEB",
                    terminalType: _this.terminalType,
                    terminalVersion: "1",
                    version: "1.0" }, { emulateJSON: true }).then(function (response) {
                    // console.log(response.body);
                    var res = JSON.parse(response.body);
                    console.log(res);
                    if (res.code === "00000") {
                        _this.packetnum += 1;
                        _this.lingmsg = true;
                        //改变红包图片为拆包
                        _this.wlogin = 2;
                        // 赋值单位
                        _this.rewardCoin = res.data.receiveGiftResult.rewardCoin;
                        //giftId
                        _this.nologgiftId = res.data.receiveGiftResult.giftId;
                        // 赋值红包大小
                        _this.coinCode = res.data.receiveGiftResult.coinCode;
                    } else if (res.code === "ACT000002") {
                        // 红包被领完了
                        _this.errmsg = 3;
                        _this.rechargemsg = true;
                    } else {
                        // if(res.code === "ACT000003")
                        // 当前人数过多
                        _this.errmsg = 4;
                        _this.rechargemsg = true;
                    }
                    // else{
                    //     // 错误弹框
                    //     _this.errmsg = 4;
                    //     _this.rechargemsg = true;
                    // }
                }, function (err) {
                    console.log(err);
                });
            } else {
                // 登录后领取注册红包
                this.$http.post(appproxypath + "/app/v2/envelopeActivity/getAfterLoginReceiveRedEnvelopeApp", {
                    activeCode: "receiveGiftAct",
                    appVersion: "1",
                    token: _this.tokens,
                    activeType: "1",
                    charset: "UTF8",
                    language: "zh",
                    terminalCode: "WEB",
                    terminalType: _this.terminalType,
                    terminalVersion: "1",
                    version: "1.0" }, { emulateJSON: true }).then(function (response) {
                    var res = JSON.parse(response.body);
                    console.log(res);
                    if (res.code === "00000") {
                        _this.packetnum += 1;
                        _this.lingmsg = true;
                        //改变红包图片为拆包
                        _this.wlogin = 2;
                        // 赋值单位
                        _this.rewardCoin = res.data.receiveGiftResult.rewardCoin;
                        //giftId
                        // _this.nologgiftId = res.data.receiveGiftResult.giftId;
                        // 赋值红包大小
                        _this.coinCode = res.data.receiveGiftResult.coinCode;
                    } else if (res.code === "ACT000002") {
                        // 红包被领完了
                        _this.errmsg = 3;
                        _this.rechargemsg = true;
                    } else {
                        // if(res.code === "ACT000003")
                        // 当前人数过多
                        if (res.code === "ACT000003") {
                            _this.errmsg = 4;
                            _this.rechargemsg = true;
                        } else {
                            if (res.msg) {
                                util.toast(res.msg);
                            }
                        }
                    }
                }, function (err) {
                    console.log(err);
                });
            }
        },
        offling: function offling() {
            this.lingmsg = false;
        },

        // 已登陆领取
        yiloginpuck: function yiloginpuck() {
            this.logipack = true;
            if (this.logstatus === false) {}
        },
        offloginling: function offloginling() {
            this.logipack = false;
        },

        // 充值拆包
        chargemoney: function chargemoney() {
            var _this = this;

            if (this.logstatus === false || this.logstatus && this.wlogin === 1) {
                // 未登录
                this.rechargemsg = true;
                this.errmsg = 1;
            } else {

                // 登录后领取红包
                this.$http.post(appproxypath + "/app/v2/envelopeActivity/getAfterLoginReceiveRedEnvelopeApp", {
                    activeCode: "receiveGiftAct",
                    appVersion: "1",
                    token: _this.tokens,
                    activeType: "2",
                    charset: "UTF8",
                    language: "zh",
                    terminalCode: "WEB",
                    terminalType: _this.terminalType,
                    terminalVersion: "1",
                    version: "1.0" }, { emulateJSON: true }).then(function (response) {
                    var res = JSON.parse(response.body);
                    console.log(res);
                    if (res.code === "00000") {
                        _this.packetnum += 1;
                        _this.logipack = true;
                        //改变充值红包图片为拆包
                        _this.chongzhi = true;
                        // 赋值单位
                        _this.czrewardCoin = res.data.receiveGiftResult.rewardCoin;
                        //giftId
                        // _this.nologgiftId = res.data.receiveGiftResult.giftId;
                        // 赋值红包大小
                        _this.czcoinCode = res.data.receiveGiftResult.coinCode;
                    } else if (res.code === "ACT000002") {
                        // 红包被领完了
                        _this.errmsg = 3;
                        _this.rechargemsg = true;
                    } else if (res.code === "ACT000004" || res.code === "222222") {
                        // 累计充币满1个ETH可拆
                        _this.errmsg = 2;
                        _this.rechargemsg = true;
                    } else {
                        // 当前人数过多
                        if (res.code === "ACT000003") {
                            _this.errmsg = 4;
                            _this.rechargemsg = true;
                        } else {
                            if (res.msg) {
                                util.toast(res.msg);
                            }
                        }
                    }
                }, function (err) {
                    console.log(err);
                });
            }
        },
        rechargebtn: function rechargebtn() {
            this.rechargemsg = false;
        }
    }
}, "filters", {}));

}());

//# sourceMappingURL=pucketActivity.main.js.map

//# sourceMappingURL=pucketActivity.main.js.map
