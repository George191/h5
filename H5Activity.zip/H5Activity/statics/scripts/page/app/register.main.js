(function () {
'use strict';

var util = {
  // 消息提示框
  toast: function toast() {
    var msg = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
    var time = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1500;

    var toast = document.createElement('div');
    toast.className = 'common-toast common-toast-show';
    toast.innerHTML = msg;
    document.body.appendChild(toast);
    toast.style.display = 'block';
    var timer = setTimeout(function () {
      toast.className = 'common-toast common-toast-hide';
      clearTimeout(timer);
      var timer2 = setTimeout(function () {
        document.body.removeChild(toast);
        clearTimeout(timer2);
      }, 200);
    }, time);
  },

  emailReg: /^([a-zA-Z0-9_\-\.\+]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/,
  // telReg: /^[0-9]*$/,
  telReg: /(^1[3|4|5|7|8]\d{9}$)|(^09\d{8}$)/,
  pwdReg: /^(?![0-9]+$)(?![a-zA-Z]+$)[\S]{6,}$/,
  // serverUrl: "http://www.upex.com:8081",
  serverUrl: "", //http://local.upex.com:8082
  objToUrl: function objToUrl(obj) {
    if (!obj) {
      return '';
    }
    var params = [];
    for (var key in obj) {
      if (obj.hasOwnProperty(key)) {
        var element = obj[key];
        params.push(encodeURIComponent(key) + '=' + encodeURIComponent(element === undefined ? '' : element));
      }
    }
    return params.join("&");
  },
  fetch: function (_fetch) {
    function fetch(_x3, _x4) {
      return _fetch.apply(this, arguments);
    }

    fetch.toString = function () {
      return _fetch.toString();
    };

    return fetch;
  }(function (path, opt) {
    try {
      opt = typeof opt === "undefined" ? {} : opt;
      var request = new Request(util.serverUrl + path, {
        method: opt.method === undefined ? "POST" : opt.method,
        body: util.objToUrl(opt.param),
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        credentials: "include"
      });
      return fetch(request).then(function (data) {
        return data.json();
      });
    } catch (e) {
      console.log("Oops, error", e);
      return {
        code: '-1',
        msg: '服务器异常'
      };
    }
  }),
  ajax: function ajax(path, opt) {
    opt = typeof opt === "undefined" ? {} : opt;
    return $.ajax({
      url: util.serverUrl + path,
      data: opt.data,
      method: opt.method === undefined ? "post" : opt.method
    });
  },
  ajax2: function ajax2(path, opt) {
    opt = typeof opt === "undefined" ? {} : opt;
    return $.ajax({
      url: util.serverUrl + path,
      data: opt.data,
      method: opt.method === undefined ? "post" : opt.method
    }).done(function (res) {

      var r = JSON.parse(res);
      if (r.code === 200) {
        $.Deferred.resolve(r);
      } else {
        if (r.msg) {
          BT.util.info(r.msg);
        }
        $.Deferred.reject(r);
      }
    }).fail(function (err) {
      BT.util.info('网络错误，请稍后重试');
    });
  },
  initNECaptcha: function (_initNECaptcha) {
    function initNECaptcha(_x5) {
      return _initNECaptcha.apply(this, arguments);
    }

    initNECaptcha.toString = function () {
      return _initNECaptcha.toString();
    };

    return initNECaptcha;
  }(function (opt) {
    var capchaIds = {
      "login": "eaa8e3b53e6b4505b4f090daae06806d",
      "register": "646c1148376d47299b31315f53956996",
      "forget": "7e40c11173af4301a50cd23acc39b845",
      "bind-google": "31995ce1d5454c3c87dc64f998db0e20",
      "unbind-google": "31995ce1d5454c3c87dc64f998db0e20",
      "update-google": "31995ce1d5454c3c87dc64f998db0e20",
      "bind-phone": "d8148e2664dd41c0bfdc43751f9db9b3",
      "unbind-phone": "d8148e2664dd41c0bfdc43751f9db9b3",
      "update-phone": "d8148e2664dd41c0bfdc43751f9db9b3",
      "bind-email": "b2d47506fe0546efa95420d957f530d1",
      "virtual-withdraw": "24e85d9ee7c54e48a0404e974778ed34",
      "virtual-withdraw-account": "24e85d9ee7c54e48a0404e974778ed34"
    };
    window.initNECaptcha = window.initNECaptcha ? window.initNECaptcha : initNECaptcha;
    initNECaptcha({
      captchaId: capchaIds[opt.captchaId], // <-- 这里填入在易盾官网申请的验证码id
      element: opt.target,
      mode: opt.mode !== undefined ? opt.mode : "float",
      onVerify: opt.onVerify
    }, opt.onInit, opt.onError);
  }),
  tickerCountDown: function tickerCountDown(second, timeout, callback) {
    var s = second;
    if (timeout === undefined) {
      timeout = 1000;
    }
    var intervalId = setInterval(function () {
      s--;
      if (s === 0) {
        clearInterval(intervalId);
        callback(-1);
      } else {
        callback(s);
      }
    }, 1000);
    return intervalId;
  }
};

var msg = {
  sendMsg: function sendMsg(sendType, msgType, address, vcode, userId, areaCode) {
    var param = void 0,
        url = void 0;
    if (sendType === 0) {
      //短信
      url = "/v1/send/regist_send_phone";
      param = {
        type: msgType,
        msgtype: 1,
        phone: address,
        NECaptchaValidate: vcode,
        userId: userId,
        areaCode: areaCode === undefined ? "86" : areaCode
      };
    } else if (sendType === 1) {
      //邮箱
      url = "/v1/send/regist_send_email";
      param = {
        type: msgType,
        msgtype: 1,
        address: address,
        NECaptchaValidate: vcode,
        userId: userId
      };
    }

    return util.fetch(url, {
      param: param
    });
  }
};

window.util = window.util || util;
window.msg = window.msg || msg;

var util$1 = {
  /**
   * 消息消失框
   */
  toast: function toast() {
    var msg = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
    var time = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1500;

    var toast = document.createElement('div');
    toast.className = 'common-toast common-toast-show';
    toast.innerHTML = msg;
    document.body.appendChild(toast);
    toast.style.display = 'block';
    var timer = setTimeout(function () {
      toast.className = 'common-toast common-toast-hide';
      clearTimeout(timer);
      var timer2 = setTimeout(function () {
        document.body.removeChild(toast);
        clearTimeout(timer2);
      }, 200);
    }, time);
  },

  /**验证方法**/
  valid: {
    checkTelephone: function checkTelephone(telephone) {
      if (!telephone) {
        util$1.toast('请输入手机号码');
        return false;
      }
      if (!/1[3457869]\d{9}/.test(telephone) || telephone.length != 11) {
        util$1.toast('手机号格式错误');
        return false;
      }
      return true;
    },
    checkPassword: function checkPassword(password) {
      if (!password) {
        util$1.toast('密码不能为空');
        return false;
      }
      if (!/[0-9]{6}/.test(password)) {
        util$1.toast('密码格式不正确');
        return false;
      }
      return true;
    },
    checkYzm: function checkYzm(yzm) {
      if (!yzm) {
        util$1.toast('请输入短信验证码');
        return false;
      }
      if (!/^\d{6}$/.test(yzm)) {
        util$1.toast('验证码格式错误');
        return false;
      }
      return true;
    },
    checkIdCard: function checkIdCard(idcard) {
      var reg = /^[1-9][0-7]\d{4}((19\d{2}(0[13-9]|1[012])(0[1-9]|[12]\d|30))|(19\d{2}(0[13578]|1[02])31)|(19\d{2}02(0[1-9]|1\d|2[0-8]))|(19([13579][26]|[2468][048]|0[48])0229))\d{3}(\d|X|x)?$/;
      if (!reg.test(idcard)) {
        util$1.toast('身份证格式不正确');
        return false;
      }
      return true;
    },
    notEmpty: function notEmpty(param, title) {
      if (!param) {
        util$1.toast(title + '不能为空');
        return false;
      }
      return true;
    },
    isInt: function isInt(v, title) {
      if (parseFloat(v) < 1 || v.indexOf('.') > -1) {
        return false;
      }
      return true;
    },
    limitNumber: function limitNumber(num, s) {
      var regparam = "(^[0-9]([0-9]+)?(\\.[0-9]{0," + s + "})?$)";
      var reg = new RegExp(regparam);
      if (!reg.test(num)) {
        return false;
      }
      return true;
    }
  },
  qs: function qs(obj) {
    return obj;
  },
  toCent: function toCent(num) {
    var numReal;
    try {
      numReal = parseFloat(num);
    } catch (e) {
      return 0;
    }
    var numStr = numReal + '';
    if (typeof numReal !== 'number' || numStr.length === 0 || num === '0' || num === 0) return 0;
    var decLength = 0;
    try {
      decLength = numStr.split('.')[1].length;
    } catch (e) {}
    numStr = numStr.replace('.', '');
    numStr = parseInt(numStr);
    if (decLength === 0) return numStr * 100;
    if (decLength == 1) return numStr + '0';
    if (decLength == 2) return numStr;
  },
  clearNumber: function clearNumber(value, num) {
    var num = num || 2;
    var value = value.replace(/[^\d.]/g, ""); // 清除“数字”和“.”以外的字符
    while (value && value[0] == '.') {
      value = value.replace(/^\./g, ""); // 验证第一个字符是数字而不是.
    }

    value = value.match(/(.{0,12})/g)[0];
    value = value.replace(/\.{2,}/g, "."); // 只保留第一个. 清除多余的
    value = value.replace(".", "$#$").replace(/\./g, "").replace("$#$", ".");
    value = value.replace(new RegExp("^(\\-)*(\\d+)\\.(\\d{0," + num + "}).*$", "gmi"), '$1$2.$3');
    return value;
  },
  isIE: function isIE() {
    var Sys = {};
    var ua = navigator.userAgent.toLowerCase();
    var s;
    (s = ua.match(/rv:([\d.]+)\) like gecko/)) ? Sys.ie = s[1] : (s = ua.match(/msie ([\d.]+)/)) ? Sys.ie = s[1] : 0;
    if (Sys.ie) {
      return true;
    } else {
      return false;
    }
  },
  trim: function trim(s) {
    return s.replace(/^\s+|\s+$/gm, '');
  },
  dateReplace: function dateReplace(s) {
    return s.replace(/\-/g, '\/');
  },

  browser: function () {
    var u = navigator.userAgent,
        app = navigator.appVersion;
    return { // 移动终端浏览器版本信息
      trident: u.indexOf('Trident') > -1, // IE内核
      presto: u.indexOf('Presto') > -1, // opera内核
      webKit: u.indexOf('AppleWebKit') > -1, // 苹果、谷歌内核
      gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1, // 火狐内核
      mobile: !!u.match(/AppleWebKit.*Mobile.*/) || !!u.match(/AppleWebKit/), // 是否为移动终端
      ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), // ios终端
      android: u.indexOf('Android') > -1 || u.indexOf('Linux') > -1, // android终端或者uc浏览器
      iPhone: u.indexOf('iPhone') > -1 || u.indexOf('Mac') > -1, // 是否为iPhone或者QQHD浏览器
      iPad: u.indexOf('iPad') > -1, // 是否iPad
      webApp: u.indexOf('Safari') == -1
      // 是否web应该程序，没有头部与底部
    };
  }(),
  loadJs: function loadJs(url, cb) {
    var script = document.createElement('script');

    script.type = "text/javascript";
    if (typeof cb != "undefined") {
      if (script.readyState) {
        script.onreadystatechange = function () {
          if (script.readyState == "loaded" || script.readyState == "complete") {
            script.onreadystatechange = null;
            if (cb) {
              cb();
            }
          }
        };
      } else {
        script.onload = function () {
          if (cb) {
            cb();
          }
        };
      }
    }
    script.src = url;
    document.body.appendChild(script);
  },
  NVC_Opt_register: function NVC_Opt_register() {
    //无痕验证
    window.NVC_Opt = {
      //无痕配置 && 滑动验证、刮刮卡通用配置
      appkey: "FFFF0N0N000000006825",
      //appkey:'CF_APP_1',
      scene: "nvc_register_h5",
      isH5: true,
      popUp: false,
      renderTo: '#captcha',
      //trans: { "key1": "code0", "nvcCode": 400 }, //测试代码
      language: "cn",
      //滑动验证长度配置
      customWidth: 300,
      nvcCallback: function nvcCallback(data) {
        // data为getNVCVal()的值，此函数为二次验证滑动或者刮刮卡通过后的回调函数
        // data跟业务请求一起上传，由后端请求AnalyzeNvc接口，接口会返回100或者900
        alert(1);
      }
    };
  },
  NVC_Opt_sec: function NVC_Opt_sec(cb) {
    //二次验证配置
    getNC().then(function () {
      NoCaptcha.upLang('cn', {
        'LOADING': "加载中...", //加载
        'SLIDER_LABEL': "请按住滑块，滑动到最右边", //等待滑动
        'CHECK_Y': "验证通过", //通过
        'ERROR_TITLE': "哎呀，出错了", //拦截
        'CHECK_N': "验证未通过", //准备唤醒二次验证
        'OVERLAY_INFORM': "经检测你当前操作环境存在风险，请输入验证码", //二次验证
        'TIPS_TITLE': "验证码错误，请重新输入", //验证码输错时的提示
        '_errorNetwork': "网络不给力，请<a href=\"javascript:NoCaptcha.reset()\">点击刷新</a>"
      });
      //NoCaptcha.reset();
      _nvc_nc.reset();
      //$("#nc_1-stage-3").html('<div onclick="NoCaptcha.reset()" >出错了</div>');
      if (cb) {
        cb();
      }
    });
  }
};

//无痕验证初始化代码
//util1.NVC_Opt_register();

window.NVC_Opt = {
  //无痕配置 && 滑动验证、刮刮卡通用配置
  appkey: "FFFF0N0N000000006825",
  //appkey:'CF_APP_1',
  scene: "nvc_register_h5",
  isH5: true,
  popUp: false,
  renderTo: '#captcha',
  //trans: { "key1": "code0", "nvcCode": 400 }, //测试代码
  language: "cn",
  //滑动验证长度配置
  customWidth: 300,
  nvcCallback: function nvcCallback(data) {
    // data为getNVCVal()的值，此函数为二次验证滑动或者刮刮卡通过后的回调函数
    // data跟业务请求一起上传，由后端请求AnalyzeNvc接口，接口会返回100或者900
    var param = {
      regName: vm.loginName,
      password: vm.password,
      regType: vm.sendType,
      NVC: data,
      recommendCode: vm.invitationCode, //推荐码
      registerCode: vm.registerLimitCode //注册码
    };
    if (vm.sendType === 1) {
      param.ecode = vm.msgCode1;
    } else {
      param.pcode = vm.msgCode;
    }
    Vue.http.post(proxypath + "/v1/regist/register",
    // "http://192.168.1.15:8080/v1/regist/register",
    vm.objToUrl(param), {
      headers: { "Content-Type": "application/x-www-form-urlencoded" }
    }).then(function (res) {
      if (res.body.code == 100 || res.body.code == 200) {
        //注册成功
        vm.zctrorfal = false;
      } else if (res.body.code == 800 || res.body.code == 900) {
        //直接拦截
        vm.isRegister = false;
        util.toast('请刷新页面后，重新注册');
      } else {
        vm.isRegister = false;
        if (res.body.msg) {
          util.toast(res.body.msg);
        }
      }
    }, function (err) {
      console.log(err);
    });
  }
};

var vm = new Vue({
  el: ".register",
  data: {
    sendType: 0,
    loginName: "", //手机号
    password: "", //一次密码
    compassword: "", //二次密码
    msgCode: "", //短信验证码
    msgCode1: "", //邮箱验证码
    xuan: true, //控制勾选
    msgText: "获取验证码",
    msgText1: "获取验证码",
    invitationCode: "", //推荐码
    registerLimitCode: "", //注册码
    isRegister: false, //控制注册
    zctrorfal: true, //控制注册成功后的显示
    isSendMsg: false,
    isSendMsg1: false,
    code: "",
    alerttr: false, //控制安全锁
    showNewCaptcha: false,
    isPassCapcha: false,
    settims: 0,
    needRegisterLimitCode: 0,
    id: "",
    cloudShow: false //控制滑块是否显示
  },
  created: function created() {
    //加载无痕代码
    util$1.loadJs('//g.alicdn.com/sd/nvc/1.1.112/guide.js?random=' + Math.random());
  },
  mounted: function mounted() {},

  methods: {
    objToUrl: function objToUrl(obj) {
      if (!obj) {
        return '';
      }
      var params = [];
      for (var key in obj) {
        if (obj.hasOwnProperty(key)) {
          var element = obj[key];
          params.push(encodeURIComponent(key) + '=' + encodeURIComponent(element === undefined ? '' : element));
        }
      }
      return params.join("&");
    },
    initNECaptchaa: function initNECaptchaa() {
      var _this = this;

      initNECaptcha({
        // config对象，参数配置
        captchaId: 'c722e7341bbd44cbacf6af4842cdb5a4',
        element: '#captcha',
        mode: 'float',
        width: '320px',
        onVerify: function onVerify(err, ret) {
          // 用户验证码验证成功后，进行实际的提交行为
          // todo
          console.log(ret);
          _this.code = ret['validate'];
          _this.isPassCapcha = true;
          _this.sendMsg();
        }
      }, function (instance) {
        console.log(instance);
        // 初始化成功后得到验证实例instance，可以调用实例的方法
      }, function (err) {
        // 初始化失败后触发该函数，err对象描述当前错误信息
        console.log(err);
      });
    },
    gouxuan: function gouxuan() {
      this.xuan = !this.xuan;
    },

    // 手机
    photo: function photo() {
      if (this.loginName === "") {
        return;
      }
      if (this.sendType === 0 && !util.telReg.test(this.loginName)) {
        util.toast("您输入的账号(邮箱或手机号码)格式有误");
      } else if (this.sendType === 0 && util.telReg.test(this.loginName)) {
        // this.valid.loginName = "";
      }
      if (this.sendType === 1 && !util.emailReg.test(this.loginName)) {
        util.toast("您输入的账号(邮箱或手机号码)格式有误");
      } else if (this.sendType === 1 && util.emailReg.test(this.loginName)) {
        // this.valid.loginName = "";
      }
    },

    // 密码
    pasworinp: function pasworinp() {
      if (this.password.length === 0) {
        return;
      }
      if (!util.pwdReg.test(this.password)) {
        util.toast("密码需包含字母、数字或特殊字符且长度在6~32位");
        // return false;
      }
      if (this.password.length < 6) {
        util.toast("密码需包含字母、数字或特殊字符且长度在6~32位");
        // return false
      }
    },
    pasworqr: function pasworqr() {
      if (this.compassword.length > 0 && this.password.length > 0 && this.password !== this.compassword) {
        util.toast("两次密码不一致");
        return false;
      }
    },

    // 验证码
    sendMsg: function sendMsg() {

      if (this.sendType === 0) {
        if (this.isSendMsg) {
          return false;
        }
        if (!this.validLoginName()) {
          return false;
        }
        if (!this.validpwd()) {
          return false;
        }
        if (!this.validcpwd()) {
          return false;
        }
        if (!this.validTwoPwd()) {
          return false;
        }
        // if(!this.isPassCapcha){
        // 	this.showNewCaptcha = true;
        // 	return false;
        // }
        var param = {
          type: 11,
          msgtype: 1,
          phone: this.loginName,
          // NECaptchaValidate: this.code,
          userId: "",
          areaCode: "86"
        };
        this.$http.post(proxypath + "/v1/send/regist_send_phone", this.objToUrl(param), { headers: { "Content-Type": "application/x-www-form-urlencoded" } }).then(function (res) {
          var _this2 = this;

          console.log(res);
          if (res.body.code === 200) {
            this.isSendMsg = true;
            this.settims = util.tickerCountDown(60, 1000, function (sec) {
              if (sec > 0) {
                _this2.msgText = sec + "s";
              } else {
                // 	this.isPassCapcha = false;
                // this.showNewCaptcha = false;
                //	this.initNECaptchaa();
                _this2.msgText = "重新获取";
                _this2.isSendMsg = false;
              }
            });
          } else {
            this.isSendMsg = false;
            //         		    this.isPassCapcha = false;
            // this.showNewCaptcha = false;
            //this.initNECaptchaa();
            if (res.body.code === 10020) {

              util.toast("该手机号已被使用");
            } else {
              util.toast(res.body.msg);
            }
          }
        }, function (err) {
          console.log(err);
        });
      } else {
        if (this.isSendMsg1) {
          return false;
        }
        if (!this.validLoginName()) {
          return false;
        }
        if (!this.validpwd()) {
          return false;
        }
        if (!this.validcpwd()) {
          return false;
        }
        if (!this.validTwoPwd()) {
          return false;
        }

        // if(!this.isPassCapcha){
        // 	this.showNewCaptcha = true;
        // 	return false;
        // }
        var _param = {
          type: 3,
          msgtype: 1,
          address: this.loginName,
          // NECaptchaValidate: this.code,
          userId: ""
        };
        this.$http.post(proxypath + "/v1/send/regist_send_email", this.objToUrl(_param), { headers: { "Content-Type": "application/x-www-form-urlencoded" } }).then(function (res) {
          var _this3 = this;

          console.log(res);
          if (res.body.code === 200) {
            this.isSendMsg1 = true;
            this.settims = util.tickerCountDown(60, 1000, function (sec) {
              if (sec > 0) {
                _this3.msgText1 = sec + "s";
              } else {
                _this3.isSendMsg1 = false;
                // this.isPassCapcha = false;
                // this.showNewCaptcha = false;
                //this.initNECaptchaa();
                _this3.msgText1 = "重新获取";
              }
            });
          } else {
            this.isSendMsg1 = false;
            //  		        this.isPassCapcha = false;
            // this.showNewCaptcha = false;
            //this.initNECaptchaa();
            if (res.body.code === 10020) {
              util.toast("该邮箱已被使用");
            } else {
              util.toast(res.body.msg);
            }
          }
        }, function (err) {
          console.log(err);
        });
      }
    },


    // 手机号
    validLoginName: function validLoginName() {
      if (this.sendType === 1) {
        //邮箱
        if (this.loginName === "") {
          util.toast("请输入邮箱账号");
          return;
        }
        if (!util.emailReg.test(this.loginName)) {
          util.toast("您输入的邮箱格式有误");
          return false;
        }
      } else {
        //手机
        if (this.loginName === "") {
          util.toast("请输入手机号");
          return;
        }
        if (!util.telReg.test(this.loginName)) {
          util.toast("您输入的手机号码格式有误");
          return false;
        }
      }
      return true;
    },
    validpwd: function validpwd() {
      if (this.password.length === 0) {
        util.toast("请设置密码");
        return false;
      }
      if (!util.pwdReg.test(this.password)) {
        util.toast("密码需包含字母、数字或特殊字符且长度在6~32位");
        return false;
      }
      if (this.password.length < 6) {
        util.toast("密码需包含字母、数字或特殊字符且长度在6~32位");
        return false;
      }
      return true;
    },
    validcpwd: function validcpwd() {
      if (this.compassword.length === 0) {
        util.toast("请再次输入密码");
        return false;
      }
      return true;
    },

    // 密码
    validTwoPwd: function validTwoPwd() {
      if (this.compassword.length > 0 && this.password.length > 0 && this.password !== this.compassword) {
        util.toast("两次密码不一致");
        return false;
      }
      return true;
    },

    // 验证码
    validMsgCode: function validMsgCode() {
      if (this.sendType === 0) {
        if (this.msgCode.length === 0) {
          util.toast("请输入短信验证码");
          return false;
        }
        if (this.msgCode.length < 6) {
          util.toast("短信验证码格式错误,请重新输入");
          return false;
        }
      } else {
        if (this.msgCode1.length === 0) {
          util.toast("请输入邮箱验证码");
          return false;
        }
        if (this.msgCode1.length < 6) {
          util.toast("邮箱验证码格式错误,请重新输入");
          return false;
        }
      }
      return true;
    },

    // 注册
    register: function register() {
      if (this.isRegister) {
        return false;
      }
      // 手机号
      if (!this.validLoginName()) {
        return false;
      }

      // 密码
      if (!this.validpwd()) {
        return false;
      }
      if (!this.validcpwd()) {
        return false;
      }
      if (!this.validTwoPwd()) {
        return false;
      }

      // 验证码
      if (!this.validMsgCode()) {
        return false;
      }

      // 如果是注册码模式需要验证注册码不为空
      if (this.needRegisterLimitCode === 1 && this.registerLimitCode === '') {
        util.toast("请输入注册码");
        return false;
      }

      if (!this.xuan) {
        util.toast("请先同意并勾选用户协议");
        return false;
      }

      this.isRegister = true;

      var param = {
        regName: this.loginName,
        password: this.password,
        regType: this.sendType,
        recommendCode: this.invitationCode, //邀请码
        registerCode: this.registerLimitCode //注册码
      };
      if (this.sendType === 1) {
        param.ecode = this.msgCode1;
      } else {
        param.pcode = this.msgCode;
      }

      // 添加人机验证的代码

      var nvcMsg = getNVCVal();

      param.NVC = nvcMsg;

      var that = this;
      // 注册
      this.$http.post(proxypath + "/v1/regist/register",
      // "http://192.168.1.15:8080/v1/regist/register",
      this.objToUrl(param), {
        headers: { "Content-Type": "application/x-www-form-urlencoded" }
      }).then(function (res) {
        // if (res.body.code === 200) {
        // 	this.zctrorfal = false;
        // } else {
        // 	this.isRegister = false;
        // 	util.toast(res.body.msg)
        // }
        if (res.body.code == 400 || res.body.code == 600) {
          this.cloudShow = true;
          //唤醒滑动验证
          getNC().then(function () {
            NoCaptcha.upLang('cn', {
              'LOADING': "加载中...", //加载
              'SLIDER_LABEL': "请按住滑块，滑动到最右边", //等待滑动
              'CHECK_Y': "验证通过", //通过
              'ERROR_TITLE': "哎呀，出错了，点击<a href=\"javascript:NoCaptcha.reset()\">刷新</a>再来一次", //拦截
              'CHECK_N': "验证未通过", //准备唤醒二次验证
              'OVERLAY_INFORM': "经检测你当前操作环境存在风险，请输入验证码", //二次验证
              'TIPS_TITLE': "验证码错误，请重新输入", //验证码输错时的提示
              '_errorNetwork': "网络不给力，请<a href=\"javascript:NoCaptcha.reset()\">点击刷新</a>"
            });
            _nvc_nc.reset();
          });
          //util1.NVC_Opt_sec();
        } else if (res.body.code == 100 || res.body.code == 200) {
          //注册成功
          that.zctrorfal = false;
        } else if (res.body.code == 800 || res.body.code == 900) {
          //直接拦截
          that.isRegister = false;
          util.toast('请刷新页面后，重新注册');
        } else {
          that.isRegister = false;
          if (res.body.msg) {
            util.toast(res.body.msg);
          }
        }
      }, function (err) {
        console.log(err);
      });
    }
  },
  filters: {},
  watch: {
    loginName: function loginName(val) {
      if (this.sendType === 0) {
        var zzval = /^[0-9]*$/;
        if (!zzval.test(val)) {
          this.loginName = val.slice(0, val.length - 1);
        }
      }
    },
    password: function password(val) {
      if (val.length > 32) {
        this.valid.password = "密码需包含字母、数字或特殊字符且长度在6~32位";
        return;
      }
    },

    "sendType": function sendType(val) {
      if (val === 0) {
        //短信
        this.placeHolder = "请输入短信验证码";
        clearInterval(this.settims);
        this.isSendMsg = false;
        this.msgText = "获取短信验证码";
      } else {
        console.log("1");
        //邮箱
        this.placeHolder = "请输入邮箱验证码";
        clearInterval(this.settims1);
        this.msgText1 = "获取邮箱验证码";
        this.isSendMsg1 = false;
      }
      this.invitationCode = "";
      // this.registerLimitCode = "";
      // this.photdisab = false;
      this.loginName = "";
      this.msgCode = "";
      this.msgCode1 = "";
      this.password = "";
      this.compassword = "";
      this.showNewCaptcha = false;
    }
  }
});

}());

//# sourceMappingURL=register.main.js.map

//# sourceMappingURL=register.main.js.map
