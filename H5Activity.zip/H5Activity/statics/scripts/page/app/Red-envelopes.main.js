(function () {
'use strict';

var util = {
  // 消息提示框
  toast: function toast() {
    var msg = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
    var time = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1500;

    var toast = document.createElement('div');
    toast.className = 'common-toast common-toast-show';
    toast.innerHTML = msg;
    document.body.appendChild(toast);
    toast.style.display = 'block';
    var timer = setTimeout(function () {
      toast.className = 'common-toast common-toast-hide';
      clearTimeout(timer);
      var timer2 = setTimeout(function () {
        document.body.removeChild(toast);
        clearTimeout(timer2);
      }, 200);
    }, time);
  },

  emailReg: /^([a-zA-Z0-9_\-\.\+]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/,
  // telReg: /^[0-9]*$/,
  telReg: /(^1[3|4|5|7|8]\d{9}$)|(^09\d{8}$)/,
  pwdReg: /^(?![0-9]+$)(?![a-zA-Z]+$)[\S]{6,}$/,
  // serverUrl: "http://www.upex.com:8081",
  serverUrl: "", //http://local.upex.com:8082
  objToUrl: function objToUrl(obj) {
    if (!obj) {
      return '';
    }
    var params = [];
    for (var key in obj) {
      if (obj.hasOwnProperty(key)) {
        var element = obj[key];
        params.push(encodeURIComponent(key) + '=' + encodeURIComponent(element === undefined ? '' : element));
      }
    }
    return params.join("&");
  },
  fetch: function (_fetch) {
    function fetch(_x3, _x4) {
      return _fetch.apply(this, arguments);
    }

    fetch.toString = function () {
      return _fetch.toString();
    };

    return fetch;
  }(function (path, opt) {
    try {
      opt = typeof opt === "undefined" ? {} : opt;
      var request = new Request(util.serverUrl + path, {
        method: opt.method === undefined ? "POST" : opt.method,
        body: util.objToUrl(opt.param),
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        credentials: "include"
      });
      return fetch(request).then(function (data) {
        return data.json();
      });
    } catch (e) {
      console.log("Oops, error", e);
      return {
        code: '-1',
        msg: '服务器异常'
      };
    }
  }),
  ajax: function ajax(path, opt) {
    opt = typeof opt === "undefined" ? {} : opt;
    return $.ajax({
      url: util.serverUrl + path,
      data: opt.data,
      method: opt.method === undefined ? "post" : opt.method
    });
  },
  ajax2: function ajax2(path, opt) {
    opt = typeof opt === "undefined" ? {} : opt;
    return $.ajax({
      url: util.serverUrl + path,
      data: opt.data,
      method: opt.method === undefined ? "post" : opt.method
    }).done(function (res) {

      var r = JSON.parse(res);
      if (r.code === 200) {
        $.Deferred.resolve(r);
      } else {
        if (r.msg) {
          BT.util.info(r.msg);
        }
        $.Deferred.reject(r);
      }
    }).fail(function (err) {
      BT.util.info('网络错误，请稍后重试');
    });
  },
  initNECaptcha: function (_initNECaptcha) {
    function initNECaptcha(_x5) {
      return _initNECaptcha.apply(this, arguments);
    }

    initNECaptcha.toString = function () {
      return _initNECaptcha.toString();
    };

    return initNECaptcha;
  }(function (opt) {
    var capchaIds = {
      "login": "eaa8e3b53e6b4505b4f090daae06806d",
      "register": "646c1148376d47299b31315f53956996",
      "forget": "7e40c11173af4301a50cd23acc39b845",
      "bind-google": "31995ce1d5454c3c87dc64f998db0e20",
      "unbind-google": "31995ce1d5454c3c87dc64f998db0e20",
      "update-google": "31995ce1d5454c3c87dc64f998db0e20",
      "bind-phone": "d8148e2664dd41c0bfdc43751f9db9b3",
      "unbind-phone": "d8148e2664dd41c0bfdc43751f9db9b3",
      "update-phone": "d8148e2664dd41c0bfdc43751f9db9b3",
      "bind-email": "b2d47506fe0546efa95420d957f530d1",
      "virtual-withdraw": "24e85d9ee7c54e48a0404e974778ed34",
      "virtual-withdraw-account": "24e85d9ee7c54e48a0404e974778ed34"
    };
    window.initNECaptcha = window.initNECaptcha ? window.initNECaptcha : initNECaptcha;
    initNECaptcha({
      captchaId: capchaIds[opt.captchaId], // <-- 这里填入在易盾官网申请的验证码id
      element: opt.target,
      mode: opt.mode !== undefined ? opt.mode : "float",
      onVerify: opt.onVerify
    }, opt.onInit, opt.onError);
  }),
  tickerCountDown: function tickerCountDown(second, timeout, callback) {
    var s = second;
    if (timeout === undefined) {
      timeout = 1000;
    }
    var intervalId = setInterval(function () {
      s--;
      if (s === 0) {
        clearInterval(intervalId);
        callback(-1);
      } else {
        callback(s);
      }
    }, 1000);
    return intervalId;
  }
};

var msg = {
  sendMsg: function sendMsg(sendType, msgType, address, vcode, userId, areaCode) {
    var param = void 0,
        url = void 0;
    if (sendType === 0) {
      //短信
      url = "/v1/send/regist_send_phone";
      param = {
        type: msgType,
        msgtype: 1,
        phone: address,
        NECaptchaValidate: vcode,
        userId: userId,
        areaCode: areaCode === undefined ? "86" : areaCode
      };
    } else if (sendType === 1) {
      //邮箱
      url = "/v1/send/regist_send_email";
      param = {
        type: msgType,
        msgtype: 1,
        address: address,
        NECaptchaValidate: vcode,
        userId: userId
      };
    }

    return util.fetch(url, {
      param: param
    });
  }
};

window.util = window.util || util;
window.msg = window.msg || msg;

var commonjsGlobal = typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : typeof self !== 'undefined' ? self : {};





function createCommonjsModule(fn, module) {
	return module = { exports: {} }, fn(module, module.exports), module.exports;
}

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) {
  return typeof obj;
} : function (obj) {
  return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
};











var classCallCheck = function (instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
};

var createClass = function () {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }

  return function (Constructor, protoProps, staticProps) {
    if (protoProps) defineProperties(Constructor.prototype, protoProps);
    if (staticProps) defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();

var promise = createCommonjsModule(function (module, exports) {
  (function (global) {

    //
    // Check for native Promise and it has correct interface
    //

    var NativePromise = global['Promise'];
    var nativePromiseSupported = NativePromise &&
    // Some of these methods are missing from
    // Firefox/Chrome experimental implementations
    'resolve' in NativePromise && 'reject' in NativePromise && 'all' in NativePromise && 'race' in NativePromise &&
    // Older version of the spec had a resolver object
    // as the arg rather than a function
    function () {
      var resolve;
      new NativePromise(function (r) {
        resolve = r;
      });
      return typeof resolve === 'function';
    }();

    //
    // export if necessary
    //

    if ('object' !== 'undefined' && exports) {
      // node.js
      exports.Promise = nativePromiseSupported ? NativePromise : Promise;
      exports.Polyfill = Promise;
    } else {
      // AMD
      if (typeof undefined == 'function' && undefined.amd) {
        undefined(function () {
          return nativePromiseSupported ? NativePromise : Promise;
        });
      } else {
        // in browser add to global
        if (!nativePromiseSupported) global['Promise'] = Promise;
      }
    }

    //
    // Polyfill
    //

    var PENDING = 'pending';
    var SEALED = 'sealed';
    var FULFILLED = 'fulfilled';
    var REJECTED = 'rejected';
    var NOOP = function NOOP() {};

    function isArray(value) {
      return Object.prototype.toString.call(value) === '[object Array]';
    }

    // async calls
    var asyncSetTimer = typeof setImmediate !== 'undefined' ? setImmediate : setTimeout;
    var asyncQueue = [];
    var asyncTimer;

    function asyncFlush() {
      // run promise callbacks
      for (var i = 0; i < asyncQueue.length; i++) {
        asyncQueue[i][0](asyncQueue[i][1]);
      } // reset async asyncQueue
      asyncQueue = [];
      asyncTimer = false;
    }

    function asyncCall(callback, arg) {
      asyncQueue.push([callback, arg]);

      if (!asyncTimer) {
        asyncTimer = true;
        asyncSetTimer(asyncFlush, 0);
      }
    }

    function invokeResolver(resolver, promise) {
      function resolvePromise(value) {
        resolve(promise, value);
      }

      function rejectPromise(reason) {
        reject(promise, reason);
      }

      try {
        resolver(resolvePromise, rejectPromise);
      } catch (e) {
        rejectPromise(e);
      }
    }

    function invokeCallback(subscriber) {
      var owner = subscriber.owner;
      var settled = owner.state_;
      var value = owner.data_;
      var callback = subscriber[settled];
      var promise = subscriber.then;

      if (typeof callback === 'function') {
        settled = FULFILLED;
        try {
          value = callback(value);
        } catch (e) {
          reject(promise, e);
        }
      }

      if (!handleThenable(promise, value)) {
        if (settled === FULFILLED) resolve(promise, value);

        if (settled === REJECTED) reject(promise, value);
      }
    }

    function handleThenable(promise, value) {
      var resolved;

      try {
        if (promise === value) throw new TypeError('A promises callback cannot return that same promise.');

        if (value && (typeof value === 'function' || (typeof value === 'undefined' ? 'undefined' : _typeof(value)) === 'object')) {
          var then = value.then; // then should be retrived only once

          if (typeof then === 'function') {
            then.call(value, function (val) {
              if (!resolved) {
                resolved = true;

                if (value !== val) resolve(promise, val);else fulfill(promise, val);
              }
            }, function (reason) {
              if (!resolved) {
                resolved = true;

                reject(promise, reason);
              }
            });

            return true;
          }
        }
      } catch (e) {
        if (!resolved) reject(promise, e);

        return true;
      }

      return false;
    }

    function resolve(promise, value) {
      if (promise === value || !handleThenable(promise, value)) fulfill(promise, value);
    }

    function fulfill(promise, value) {
      if (promise.state_ === PENDING) {
        promise.state_ = SEALED;
        promise.data_ = value;

        asyncCall(publishFulfillment, promise);
      }
    }

    function reject(promise, reason) {
      if (promise.state_ === PENDING) {
        promise.state_ = SEALED;
        promise.data_ = reason;

        asyncCall(publishRejection, promise);
      }
    }

    function publish(promise) {
      var callbacks = promise.then_;
      promise.then_ = undefined;

      for (var i = 0; i < callbacks.length; i++) {
        invokeCallback(callbacks[i]);
      }
    }

    function publishFulfillment(promise) {
      promise.state_ = FULFILLED;
      publish(promise);
    }

    function publishRejection(promise) {
      promise.state_ = REJECTED;
      publish(promise);
    }

    /**
    * @class
    */
    function Promise(resolver) {
      if (typeof resolver !== 'function') throw new TypeError('Promise constructor takes a function argument');

      if (this instanceof Promise === false) throw new TypeError('Failed to construct \'Promise\': Please use the \'new\' operator, this object constructor cannot be called as a function.');

      this.then_ = [];

      invokeResolver(resolver, this);
    }

    Promise.prototype = {
      constructor: Promise,

      state_: PENDING,
      then_: null,
      data_: undefined,

      then: function then(onFulfillment, onRejection) {
        var subscriber = {
          owner: this,
          then: new this.constructor(NOOP),
          fulfilled: onFulfillment,
          rejected: onRejection
        };

        if (this.state_ === FULFILLED || this.state_ === REJECTED) {
          // already resolved, call callback async
          asyncCall(invokeCallback, subscriber);
        } else {
          // subscribe
          this.then_.push(subscriber);
        }

        return subscriber.then;
      },

      'catch': function _catch(onRejection) {
        return this.then(null, onRejection);
      }
    };

    Promise.all = function (promises) {
      var Class = this;

      if (!isArray(promises)) throw new TypeError('You must pass an array to Promise.all().');

      return new Class(function (resolve, reject) {
        var results = [];
        var remaining = 0;

        function resolver(index) {
          remaining++;
          return function (value) {
            results[index] = value;
            if (! --remaining) resolve(results);
          };
        }

        for (var i = 0, promise; i < promises.length; i++) {
          promise = promises[i];

          if (promise && typeof promise.then === 'function') promise.then(resolver(i), reject);else results[i] = promise;
        }

        if (!remaining) resolve(results);
      });
    };

    Promise.race = function (promises) {
      var Class = this;

      if (!isArray(promises)) throw new TypeError('You must pass an array to Promise.race().');

      return new Class(function (resolve, reject) {
        for (var i = 0, promise; i < promises.length; i++) {
          promise = promises[i];

          if (promise && typeof promise.then === 'function') promise.then(resolve, reject);else resolve(promise);
        }
      });
    };

    Promise.resolve = function (value) {
      var Class = this;

      if (value && (typeof value === 'undefined' ? 'undefined' : _typeof(value)) === 'object' && value.constructor === Class) return value;

      return new Class(function (resolve) {
        resolve(value);
      });
    };

    Promise.reject = function (reason) {
      var Class = this;

      return new Class(function (resolve, reject) {
        reject(reason);
      });
    };
  })(typeof window != 'undefined' ? window : typeof commonjsGlobal != 'undefined' ? commonjsGlobal : typeof self != 'undefined' ? self : commonjsGlobal);
});

var Promise$1 = promise.Promise;

function request(url, data, type) {
	var data = data || {};
	var url = url || '';
	var type = type || 'post';
	if (!url && typeof url != 'string') {
		console.log('传入的url有问题');
		return;
	}
	if (url.charAt(0) != '/') {
		url = '/' + url;
	}
	var param = {
		type: type,
		url: proxypath + url,
		data: data
	};
	return new Promise$1(function (resolve, reject) {
		GB.ajax2(param).done(function (result) {
			resolve(result);
		}).fail(function (data) {
			reject(data);
		});
	});
}

var _post = function _post(url, data) {
	return request(url, data, 'post');
};
var _get = function _get(url, data) {
	return request(url, data, 'get');
};

var query = function () {
	function query(prefix) {
		classCallCheck(this, query);

		if (!prefix || typeof prefix != 'string') throw new Error('prefix is undefine');
		if (prefix.charAt(prefix.length - 1) != '/') prefix += '/';
		this.prefix = prefix;
		//过滤器，默认直接将结果传递，如果需要单独处理需自己实现
		this.queryFilter = function (res) {
			return res;
		};
		this.exceptFilter = function (res) {
			return Promise$1.reject(res);
		};
	}

	createClass(query, [{
		key: 'get',
		value: function get$$1(method, data) {
			return _get(this.prefix + method, data).then(this.queryFilter).catch(this.exceptFilter);
		}
	}, {
		key: 'post',
		value: function post(method, data) {
			return _post(this.prefix + method, data).then(this.queryFilter).catch(this.exceptFilter);
		}
	}]);
	return query;
}();

var isWX = function isWX() {
	var ua = navigator.userAgent.toLowerCase();
	return (/micromessenger/.test(ua)
	);
};

var token = GB.utils.GetRequest()['token'] || '';
var resource = GB.utils.GetRequest()['resource'] || '';
var recommendCode = GB.utils.GetRequest()['recommendCode'] || '';

var vue = new Vue({
	el: ".red-avtivity",
	data: {
		redswitch: true, //控制红包拆与不拆
		redshu: {}, //获取红包的数据  
		redrate: null, //红包转换汇率
		token: token,
		resource: resource,
		hui: 0
	},
	mounted: function mounted() {},
	created: function created() {
		this.rate();
		console.log(this.resource);
		console.log(this.token);
	},

	methods: {
		objToUrl: function objToUrl(obj) {
			if (!obj) {
				return '';
			}
			var params = [];
			for (var key in obj) {
				if (obj.hasOwnProperty(key)) {
					var element = obj[key];
					params.push(encodeURIComponent(key) + '=' + encodeURIComponent(element === undefined ? '' : element));
				}
			}
			return params.join("&");
		},

		// 弹框
		dialog: function dialog() {

			var html = $("#dialog-template").html();

			GB.utils.showhtml({
				content: html,
				eventHandler: function eventHandler() {
					var $boudingBox = this.boudingBox;

					//函数内部的 this  是 这个 dialog对象 

					var that = this;
					$boudingBox.on("click", '.sure-btn', function () {

						that.destroy();
					});
				}
			});
		},

		// 拆红包
		chai: function chai() {
			var _this = this;

			console.log("红包已拆");
			var param = { activeCode: "receiveGiftAct", activeType: 1, token: this.token // 加token
			};var url = this.resource == 2 ? proxypath + "/v1/envelopeActivity/notLoggedEnvelope" : proxypath + "/v1/envelopeActivity/getAfterLoginReceiveRedEnvelopeH5";
			this.$http.post(url, param, { emulateJSON: true }).then(function (res) {
				console.log(res);
				if (res.body.code == 200) {
					if (_this.resource == 2) {
						_this.redshu = res.body.data;
						console.log(_this.redshu);
						_this.hui = Number(_this.redrate * _this.redshu.rewardCoin).toFixed(2);
						_this.redswitch = false;
					} else {
						if (isWX()) {
							window.location.href = proxypathone + "/html/pages/redactivity/ios-course.html?token=" + _this.token;
						} else {
							window.location.href = proxypathone + "/html/pages/redactivity/ios-course.html?flag=1&token=" + _this.token; // 非微信环境 进行跳转 
						}
					}
				} else {
					if (res.body.code === 305) {
						util.toast("获取红包信息失败！");
						return;
					} else {
						if (res.body.code === 302) {
							util.toast("太遗憾了，红包被领完了");
							return;
						}
						if (res.body.code === 303) {
							util.toast("当前人数过多，请稍后再试~");
							return;
						}
						if (res.body.code === 300) {
							util.toast("您操作过于频繁");
							return;
						}
						if (res.body.msg) {
							util.toast(res.body.msg);
							return;
						}
					}
				}
			}, function (err) {
				console.log(err);
			});
			// $.get(proxypath+"/v1/envelopeActivity/notLoggedEnvelope",function(res){
			// 	console.log(res)
			// })
		},

		// 汇率转换
		rate: function rate() {
			var _this2 = this;

			this.$http.post(proxypath + "/v1/envelopeActivity/tradingCurrency", {}, { emulateJSON: true }).then(function (res) {
				console.log(res);
				if (res.body.code === 200) {
					_this2.redrate = res.body.data;
				} else {
					if (res.body.msg) {
						util.toast(res.body.msg);
					}
				}
			}, function (err) {
				console.log(err);
			});
		},

		// 注册领取红包
		btnzce: function btnzce() {
			window.location.href = proxypathone + "/html/pages/redactivity/red-register.html?giftId=" + this.redshu.giftId + "&recommendCode=" + recommendCode;
		}
	},
	filters: {}
});

}());

//# sourceMappingURL=Red-envelopes.main.js.map

//# sourceMappingURL=Red-envelopes.main.js.map
