(function () {
'use strict';

var util = {
  // 消息提示框
  toast: function toast() {
    var msg = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
    var time = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1500;

    var toast = document.createElement('div');
    toast.className = 'common-toast common-toast-show';
    toast.innerHTML = msg;
    document.body.appendChild(toast);
    toast.style.display = 'block';
    var timer = setTimeout(function () {
      toast.className = 'common-toast common-toast-hide';
      clearTimeout(timer);
      var timer2 = setTimeout(function () {
        document.body.removeChild(toast);
        clearTimeout(timer2);
      }, 200);
    }, time);
  },

  emailReg: /^([a-zA-Z0-9_\-\.\+]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/,
  // telReg: /^[0-9]*$/,
  telReg: /(^1[3|4|5|7|8]\d{9}$)|(^09\d{8}$)/,
  pwdReg: /^(?![0-9]+$)(?![a-zA-Z]+$)[\S]{6,}$/,
  // serverUrl: "http://www.upex.com:8081",
  serverUrl: "", //http://local.upex.com:8082
  objToUrl: function objToUrl(obj) {
    if (!obj) {
      return '';
    }
    var params = [];
    for (var key in obj) {
      if (obj.hasOwnProperty(key)) {
        var element = obj[key];
        params.push(encodeURIComponent(key) + '=' + encodeURIComponent(element === undefined ? '' : element));
      }
    }
    return params.join("&");
  },
  fetch: function (_fetch) {
    function fetch(_x3, _x4) {
      return _fetch.apply(this, arguments);
    }

    fetch.toString = function () {
      return _fetch.toString();
    };

    return fetch;
  }(function (path, opt) {
    try {
      opt = typeof opt === "undefined" ? {} : opt;
      var request = new Request(util.serverUrl + path, {
        method: opt.method === undefined ? "POST" : opt.method,
        body: util.objToUrl(opt.param),
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        credentials: "include"
      });
      return fetch(request).then(function (data) {
        return data.json();
      });
    } catch (e) {
      console.log("Oops, error", e);
      return {
        code: '-1',
        msg: '服务器异常'
      };
    }
  }),
  ajax: function ajax(path, opt) {
    opt = typeof opt === "undefined" ? {} : opt;
    return $.ajax({
      url: util.serverUrl + path,
      data: opt.data,
      method: opt.method === undefined ? "post" : opt.method
    });
  },
  ajax2: function ajax2(path, opt) {
    opt = typeof opt === "undefined" ? {} : opt;
    return $.ajax({
      url: util.serverUrl + path,
      data: opt.data,
      method: opt.method === undefined ? "post" : opt.method
    }).done(function (res) {

      var r = JSON.parse(res);
      if (r.code === 200) {
        $.Deferred.resolve(r);
      } else {
        if (r.msg) {
          BT.util.info(r.msg);
        }
        $.Deferred.reject(r);
      }
    }).fail(function (err) {
      BT.util.info('网络错误，请稍后重试');
    });
  },
  initNECaptcha: function (_initNECaptcha) {
    function initNECaptcha(_x5) {
      return _initNECaptcha.apply(this, arguments);
    }

    initNECaptcha.toString = function () {
      return _initNECaptcha.toString();
    };

    return initNECaptcha;
  }(function (opt) {
    var capchaIds = {
      "login": "eaa8e3b53e6b4505b4f090daae06806d",
      "register": "646c1148376d47299b31315f53956996",
      "forget": "7e40c11173af4301a50cd23acc39b845",
      "bind-google": "31995ce1d5454c3c87dc64f998db0e20",
      "unbind-google": "31995ce1d5454c3c87dc64f998db0e20",
      "update-google": "31995ce1d5454c3c87dc64f998db0e20",
      "bind-phone": "d8148e2664dd41c0bfdc43751f9db9b3",
      "unbind-phone": "d8148e2664dd41c0bfdc43751f9db9b3",
      "update-phone": "d8148e2664dd41c0bfdc43751f9db9b3",
      "bind-email": "b2d47506fe0546efa95420d957f530d1",
      "virtual-withdraw": "24e85d9ee7c54e48a0404e974778ed34",
      "virtual-withdraw-account": "24e85d9ee7c54e48a0404e974778ed34"
    };
    window.initNECaptcha = window.initNECaptcha ? window.initNECaptcha : initNECaptcha;
    initNECaptcha({
      captchaId: capchaIds[opt.captchaId], // <-- 这里填入在易盾官网申请的验证码id
      element: opt.target,
      mode: opt.mode !== undefined ? opt.mode : "float",
      onVerify: opt.onVerify
    }, opt.onInit, opt.onError);
  }),
  tickerCountDown: function tickerCountDown(second, timeout, callback) {
    var s = second;
    if (timeout === undefined) {
      timeout = 1000;
    }
    var intervalId = setInterval(function () {
      s--;
      if (s === 0) {
        clearInterval(intervalId);
        callback(-1);
      } else {
        callback(s);
      }
    }, 1000);
    return intervalId;
  }
};

var msg = {
  sendMsg: function sendMsg(sendType, msgType, address, vcode, userId, areaCode) {
    var param = void 0,
        url = void 0;
    if (sendType === 0) {
      //短信
      url = "/v1/send/regist_send_phone";
      param = {
        type: msgType,
        msgtype: 1,
        phone: address,
        NECaptchaValidate: vcode,
        userId: userId,
        areaCode: areaCode === undefined ? "86" : areaCode
      };
    } else if (sendType === 1) {
      //邮箱
      url = "/v1/send/regist_send_email";
      param = {
        type: msgType,
        msgtype: 1,
        address: address,
        NECaptchaValidate: vcode,
        userId: userId
      };
    }

    return util.fetch(url, {
      param: param
    });
  }
};

window.util = window.util || util;
window.msg = window.msg || msg;

var vue = new Vue({
	el: ".rate",
	data: {
		arr: []
	},
	created: function created() {

		// this.$http.post(proxypath+"/v1/bottom/fee_rate_list").then((res)=>{
		// 	console.log(res)
		//        if (res.body.code === 200) {
		//                  this.arr = res.body.data
		//        }
		// },(err)=>{

		// })


		// $.post("/v1/bottom/fee_rate_list", function (data) {
		//           $(".loader-total").hide();
		//           if (data.code === 200) {
		//               var tableList = $(".table_list");
		//               for (var i = 0; i < data.data.length; i++) {
		//                   var tableLi = $("<div class='table_li'></div>");
		//                   var span1 = $("<span></span>").text(data.data[i].fshortname);
		//                   var span2 = $("<span></span>").text(data.data[i].makerFeeRate);
		//                   var span3 = $("<span></span>").text(data.data[i].takerFeeRate);
		//                   tableLi.append(span1).append(span2).append(span3);
		//                   tableList.append(tableLi);
		//               }
		//           } else {
		//               $(".no-data").show();
		//           }
		//       })
	},
	mounted: function mounted() {
		// this.$http.post(proxypath+"/v1/bottom/fee_rate_list").then((res)=>{
		// 	// console.log(res)
		//        if (res.body.code === 200) {
		//                  this.arr = res.body.data
		//        }
		// },(err)=>{
		// 	this.errMsg = JSON.stringify(err);
		// 	util.toast("数据获取失败")
		// })
		var that = this;
		$.post(proxypath + "/v1/bottom/fee_rate_list", function (res) {
			console.log(res);
			that.arr = res.code;
			if (res.code === 200) {
				that.arr = res.data;
			}
		});
	},

	methods: {},
	filters: {}
});

}());

//# sourceMappingURL=Rate-description.main.js.map

//# sourceMappingURL=Rate-description.main.js.map
