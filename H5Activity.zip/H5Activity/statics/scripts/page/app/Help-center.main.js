(function () {
'use strict';

var vue = new Vue({
	el: ".help-center",
	data: {
		cxian1: false,
		cxian2: false,
		cxian3: false,
		cxian4: false
	},
	mounted: function mounted() {},

	methods: {
		dian: function dian(index) {
			// if (index==="4") {
			// 	this.cxian=!this.cxian
			// }
			switch (index) {
				case "1":
					this.cxian1 = !this.cxian1;
					this.cxian2 = false;
					this.cxian3 = false;
					this.cxian4 = false;
					break;
				case "2":
					this.cxian2 = !this.cxian2;
					this.cxian1 = false;
					this.cxian3 = false;
					this.cxian4 = false;
					break;
				case "3":
					this.cxian3 = !this.cxian3;
					this.cxian2 = false;
					this.cxian1 = false;
					this.cxian4 = false;
					break;
				default:
					this.cxian4 = !this.cxian4;
					this.cxian2 = false;
					this.cxian3 = false;
					this.cxian1 = false;
			}
		}
	},
	filters: {}
});

}());

//# sourceMappingURL=Help-center.main.js.map

//# sourceMappingURL=Help-center.main.js.map
