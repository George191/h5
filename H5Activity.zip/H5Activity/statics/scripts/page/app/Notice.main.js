(function () {
'use strict';

var vue = new Vue({
						el: ".notice",
						data: {
												list: {}
						},
						mounted: function mounted() {
												// 获取url中的id
												function getRequest() {
																		var url = window.location.search; //获取url中"?"符后的字串
																		var theRequest = new Object();
																		if (url.indexOf("?") != -1) {
																								var str = url.substr(1);
																								var strs = str.split("&");
																								for (var i = 0; i < strs.length; i++) {

																														theRequest[strs[i].split("=")[0]] = decodeURI(strs[i].split("=")[1]);
																								}
																		}
																		return theRequest;
												}
												var id = getRequest().id;
												console.log(id);

												this.$http.post("http://devapp.upex.com:8086/app/v2/getNoticeById", {
																		appVersion: "1",
																		charset: "UTF8",
																		language: "zh",
																		terminalCode: "WEB",
																		terminalType: "1",
																		terminalVersion: "1",
																		version: "1.0",
																		noticeId: id }, { emulateJSON: true }).then(function (response) {
																		console.log(response.data);
																		// var shu = JSON.parse("("+response.data+")")
																		var shu = JSON.parse(response.data);
																		// this.list.push(shu.data)
																		this.list = shu.data;
																		console.log(this.list);
												}, function (err) {
																		console.log(err);
												});
						},

						methods: {},
						filters: {
												updatetime: function updatetime(val) {
																		var time = val.split(" ")[0].split("-");
																		for (var i = 0; i < time.length; i++) {
																								time[i] = time[i].charAt(0) === "0" ? time[i].slice(1) : time[i];
																		}
																		var ctime = time[0] + '年' + time[1] + '月' + time[2] + '号';
																		return ctime;
												}
						}
});

}());

//# sourceMappingURL=Notice.main.js.map

//# sourceMappingURL=Notice.main.js.map
