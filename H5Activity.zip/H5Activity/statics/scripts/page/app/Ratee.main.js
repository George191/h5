(function () {
'use strict';

var vue = new Vue({
	el: ".help-center",
	data: {},
	mounted: function mounted() {},

	methods: {},
	filters: {}
});

}());

//# sourceMappingURL=Ratee.main.js.map

//# sourceMappingURL=Ratee.main.js.map
