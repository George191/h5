(function () {
'use strict';

var uid = GB.utils.GetRequest()['uid'] || '';
var recommendCode = GB.utils.GetRequest()['recommendCode'] || '';
var vue = new Vue({
	el: "#coinworld",
	data: {
		uid: uid
	},
	created: function created() {},
	mounted: function mounted() {},

	methods: {
		tiao: function tiao() {
			window.location.href = basePath + "/html/pages/joint/world-premiere.html?&channelCode=bsj-register&uid=" + this.uid + "&recommendCode=" + recommendCode;
		}
	},
	filters: {}
});

}());

//# sourceMappingURL=coin-world.main.js.map

//# sourceMappingURL=coin-world.main.js.map
